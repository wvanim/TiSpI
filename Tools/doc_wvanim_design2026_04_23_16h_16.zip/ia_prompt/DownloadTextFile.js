/*
 * Installation : rechercher "TODO inscrire le chemin du dossier sur le serveur"
 */

const buttons = document.querySelectorAll("button");

function setSuccess(button, message) {
    button.parentNode.querySelector("#status").innerHTML = message;
    if(cptOk-->0){
        alert("Paste into the prompt field (Ctrl+V)");
    }
}

function setError(button, message) {
    button.parentNode.querySelector("#status").innerHTML = message;
}

function toggleButtons(disabled) {
    buttons.forEach(btn => btn.disabled = disabled);
}
function downloadFileText(button, callbackFc, ...params){ 
    return downloadFileText_(button)
        .then(text => callbackFc(text, ...params));
}
function downloadFileText(button, callbackFc = null, ...params){ // new
        const id = button.getAttribute("data-id");
        toggleButtons(true);
        
        // TODO inscrire le chemin du dossier sur le serveur 
        const server_folder = "https://www.wvanim.fr/p/ia_prompt";
        //alert( `${server_folder}/download_textfile.php?id=${server_folder}/${id}`);
        return fetch( `${server_folder}/download_textfile.php?id=${id}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erreur HTTP");
                }
                return response.json();
            })
            .then(data => {
                if (data.status === "ok") {
                    let text = data.content;
                    if (typeof callbackFc === "function") {
                        // Le callback peut modifier le retour,
                        // Ex : une vérification fausse -> retourne un texte correctif à transmettre à l'IA
                        text = callbackFc(text, ...params);
                    }
                    navigator.clipboard.writeText(text)
                        .then(() => {
                            setSuccess(button,"Text copied to the clipboard,<br>paste it (Ctrl+V) into your AI input field. ");
                        })
                        .catch(() => {
                            setError(button,"Copie dans le presse-papier impossible");
                        });
                    return text;
                } else {
                    throw new Error(data.message);
                }
            })
            .catch(err => {
                setError(button, "Erreur : " + err.message);
                return false;
            })
            .finally(() => {
                toggleButtons(false);
                return false;
            });
} 

async function copyImage(url) {
    try {
        const response = await fetch(url); //"https://www.wvanim.fr/p/test.png");
        const blob = await response.blob();

        await navigator.clipboard.write([
            new ClipboardItem({
                [blob.type]: blob
            })
        ]);
        if(cptOk-->0){
            alert("Copy the image to your clipboard\nand paste it (Ctrl+V) into your AI input field.");
        }
    } catch (err) {
        console.error("Error:", err);
    }
}
let cptOk = 2;