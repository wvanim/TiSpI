// 1ère pass correcte, quelques améliorations de détail.

M P moduleRequestPHP
  doc`
    ##role
      Requête PHP asynchrone robuste, pilotée par tags, avec timeout, abort et retour détaillé.
  `

  contract {
    timeline_isolated = true
    returns {
      success : --sender --success --response
      error   : --sender --error   --response   // contient code + message + status
      produces: --response
    }
  }

  params {
    string  --url
    array   --params
    P       --sender
    func    --success
    func    --error
    int     --timeout = 30000     // en milli secondes
    bool    --autoJson = true
  }

  modele {
    P <pieceName>

      V request = () => { this.request.sendTag(REQUEST_PENDING) }
      V abort   = () => { this.request.sendTag(REQUEST_ABORT) }

      F f0 group
        P request
          T tag[
            0: REQUEST_WAIT;     // repos - figé
            1: REQUEST_PENDING;
            2: REQUEST_OK;
            3: REQUEST_ERROR;
            4: REQUEST_ABORT     // nouvel état
          ]

          T stop[0]

          T face[1:fPending ; 2:fOk ; 3:fError]

          T sendTag[
            2: --sender --success --response, this REQUEST_WAIT;
            3: --sender --error   --response, this REQUEST_WAIT;
            4: this REQUEST_WAIT;   // après abort, on retourne en WAIT
          ]

          T action[
            1: Tispi.io.phpRequest(this, --url, --params, --timeout, --autoJson);
          ]

          F fPending text "Requête en cours..."
          F fOk      text ""
          F fError   text ""
  }