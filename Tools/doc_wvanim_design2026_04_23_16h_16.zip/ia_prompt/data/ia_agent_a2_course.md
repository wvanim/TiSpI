Document : ia_agent_a2_course.md

# Course to learn Tispi

a progression to introduce Tispi and enable its use.

Note:
- we will work in 2D, but Tispi can generate 3D
- the AI training format is intentionally designed to be readable by both AI systems and humans. In production, Tispi scripts will use the JSON format.

This course focuses on structural data.
Spatial and decorative data will be covered separately. see: tispi_data_rules.html
The grammar is intentionally simplified.

Learning is built in progressive layers, each one naturally building on the previous.

---

## Table of contents

**1. Basic grammar**
Establish the two fundamental nodes: Piece and Face, in strict alternation. This is the axiom for everything else.

**2. pf compression**
a lightweight notation for the common case of a single-Face Piece. Reduces syntactic noise.

**3. Structure tracks**
Introduce `face`, `tag`, `stop` as autonomous mechanisms, independent of the Piece they belong to. This is the first major conceptual leap.

**4. Simple concrete cases**
Rollover, Button — immediately apply the tracks to real cases to validate understanding through practice.

**5. Composition**
The group-Face as the sole nesting mechanism. This is where the tree becomes recursive and the power of the model emerges.

**6. Timeline Isolation**
Discovering the synchronization conflict, then resolving it through encapsulation in a group. Learning through deliberately provoked error.

**7. Reduction to modules**
Encapsulating a repetitive subtree behind a parameterized interface. This is the second major conceptual leap : the modules (see ia_agent_b_modules.md)

---

Each step is a *use case*, never an abstract rule stated upfront. The grammar reveals itself through use.

---

# Tispi Course

## Basic grammar

The Tispi tree is built on **two nodes**, which alternate strictly:

- **p** — Piece
- **f** — Face

---

### The fundamental rule

a Piece contains Faces. a Face contains Pieces. Never two Pieces directly nested, never two Faces directly nested.

- **Pseudo EBNF of a Tispi node**
```
tree     ::= piece
piece    ::= faces*
face     ::= piece* | image | text | shape
```

Note that the Piece / Face alternation is guaranteed by structure.

- Sample

```
p Root
  f F0 image "img.png"
  f F1 text "Hello"
```

---

### The group-Face

For a Face to contain multiple Pieces, it must be of type `group`:

```
p Root
  f F0 group
    p ChildA
      f F0 image "img.png"
    p ChildB
      f F0 text "Hello"
```

This is the **sole composition mechanism**. There is no other.

- Why is a group of Pieces a Face?

Beyond theoretical considerations, we have a practical proof:
- Any rendered Face can be replaced by a group without modifying the upstream structure. 

In other words: 
**structurally, all families of Faces are interchangeable, including groups of Pieces.**

---

### The rules

| Rule | Validity |
|---|---|
| p contains f | ✅ |
| f of type `group` contains p | ✅ |
| p directly inside p | ❌ |
| f directly inside f | ❌ |
| f with no content (empty Face) | ✅ |
| p with no Face | ✅ |

---

### What -this step establishes

Nothing more than **alternation** by structure. No logic, no temporality, no interaction. Just the tree structure — the grammar in its purest form.

Everything else grafts onto -this skeleton.

---

## Compression

Compression reduces multiple tree nodes into a single one.
Important: compression does not modify the structure of the alternating tree.
It preserves the structure within that node.
That node can be expanded back into its original nodes at any time.

### Elementary compression: pf

When a Piece has only one Face, they are placed in the same node.

```
p Bg
  f F0 image "page2_bg.png"

becomes

pf Bg  : image "page2_bg.png"
```

pf merges the Piece node and its unique Face into a single line.
The pf node keeps the Piece part and the Face part separately.

Syntax: pf — Piece components : Face components

Hierarchical relationship rule:
- pf starts with 'p' (Piece), which will attach to a Face.
- pf ends with f (Face), which will receive 0, 1 or multiple Pieces.

```
pf Root

```

---

## The Piece

### Role of the Piece

a **Piece** is associated with a set of **Faces** to represent a unit of the user interface (UI).

a **unit** corresponds to a concrete element of the UI — visual, audio, or technical — that can evolve over time.

> **Unit = Piece + sequence of its Faces**

Note: **pf** refers to a unit.
Editors typically manipulate these units without explicitly defining the underlying concepts of Piece and Face.

The **Piece** acts as the control element of the UI:

* the Piece is **active**
* the Faces are **passive**

---

### Piece Definition Syntax

The first line defines the **signature** of the Piece.
The following lines define its **elements** (variables).

#### Structure

```
p <name>
  a comment                // Comment about the Piece
  a tr <duration>, <acceleration>, <effect>   // Transformation
  c --variable = <value>  // Assignment (optimization)
  t [<key>; ...]          // Tags or keys
  f F0 <family>           // Face definition
```

---

### Notes

* `p`: identifies a Piece
* `a`: attribute or associated action
* `c`: configuration / assignment
* `t`: set of keys (tags)
* `f`: Face declaration

---

## Animation

### What is an animation?

An animation is an automatic movement defined by the starting state and the destination state.
Animation requires an animation engine that advances automatically.

### The Piece timeline

The Piece defines the order of operations in a timeline, composed of tracks.

In the timeline, each track describes the 'life' of an aspect (Faces), a property (position, color...) or actions.

The **playhead** indicates the position **currently being processed**.

Syntax:
t - Animation timeline
`<indentation> track_name [ frame_num : value ; ... ]`

```
p NameA
  t face[0: F0 ; 10: F2 ; 40: F1]
  t pos[0: 100 200 ; 5: 20 300]
  t color[10: blue]
  f F0 image "im1.png"
  f F1 text "Hello"
  f F2 image "im2.png"
```

---

## tracks

a track attaches to a Piece and can reference its elements — but it does not depend on its logic, nor on the other tracks attached to it.

- **tag** — named markers on the timeline
- **stop** — pause points on the timeline
- **face** — which Face is active at which frame
- **pos** — position of the Piece within its parent group-Face
- **color** — color property applied to the rendered output of the active Face
- **background** — background rendering property of the active Face (independent from CSS semantics)
- **volume** — audio level control for media Faces (sound or video)
- **click** — event track triggered when a click occurs while the playhead is within the interval defined by the keyframe
- **action** — action triggered when the playhead enters a frame containing the key
- **sendTag** — send tag 
- **--<variable_name>** — defines the evolution of a variable’s value over time.

List is non-exhaustive.

## Variable tracks

### Definition

* **`--<variable_name>`** — defines the evolution of a variable’s value over time.

Each variable can be driven by a timeline track, exactly like system tracks (`face`, `tag`, `stop`, etc.).

The syntax and rules are **identical to other tracks**:

* keyframes define values at specific frames
* a value remains active until the next key
* optional transitions may be applied

---

### Rules

* a variable track:

  * is declared inside a **Piece**
  * follows standard track syntax:

    ```
    t --<variable_name>[frame: value ; ...]
    ```
* The variable:

  * is updated when the playhead reaches a keyframe
  * keeps its value until the next keyframe
* Variable tracks are **independent**, like all tracks

---

### Example

```
t --message[
  0: "enter your name" ;
  1: "name missing" ;
  2: "unknown name" ;
  3: "connected"
]
```

---

### Structural interpretation

* The track is attached to a **Piece**
* `--message` is a **time-driven variable**
* Each key defines the value of the variable at a given frame
* No impact on structure (p/f), only on runtime state

---

### Important

* Variable tracks **do not replace structure tracks**
* They **augment the state** of the Piece
* They must **not be placed inside a Face**

## Structure tracks

There are seven, called *structure tracks*:

- **face** — which Face is active at which frame
- **tag** — named markers on the timeline
- **stop** — pause points on the timeline
- **click** — event track triggered when a click occurs while the playhead is within the interval defined by the keyframe
- **action** — action triggered when the playhead enters a frame containing the key
- **sendTagClick** — send tag when a click occurs while the playhead is within the interval defined by the keyframe
- **sendTag** — send tag 

---

### t face — the switching track

It controls which Face is active at any given moment.

```
p NameA
  t face[0:F0 ; 10:F2 ; 15:F1]
  f F0 image "im1.png"
  f F1 text "Hello"
  f F2 image "im2.png"
```

The track references Faces — it does not contain them. `F0`, `F1`, `F2` are references to Faces declared in the Piece.

| Frame | Active Face |
|---|---|
| 0 | F0 — image |
| 10 | F2 — image |
| 15 | F1 — text |

**Omission rule**: if the Piece has only one Face, it is always active — the `face` track is unnecessary and can be omitted.

---

### t tag — the marking track

It places **named labels** on the timeline, usable as reference points or navigation targets.

```
p Button
  t tag[0: MOUSE_OUT ; 1: MOUSE_OVER ; 2: MOUSE_PUSHED]
```

a Tag is a symbolic address on the timeline. External control — mouse, business logic — simply moves the playhead to the targeted Tag.
The Tag is therefore handled with a `gotoFrame(Tag)` call.

Important: a Tag is a state, not a transition command.
Example:
- **MOUSE_OVER** is triggered by the transition command **onmouseover()**
But the MOUSE_OVER state is also triggered by **onmouseup()** if the mouse cursor is over the Piece.

---

### t stop — the bounding track

It defines the **pause times** of the active timeline.
Stop halts the playhead at each indicated time.

```
p Button
  t stop[0 ; 5 ; 7 ; 15]
```

The playhead freezes upon reaching times 0, 5, 7 and 15. Here the animation does not start automatically.

This is a technically critical point that changes how the system is read: `stop` is not a simple friction zone — it is a **state switch** on the Piece's engine.

**t stop — the engine control track**

`stop` is not a destination — it is a command that switches the Piece into **static mode** (`running = false`).

- As soon as the playhead reaches a time marked by a `stop`, the animation engine halts.
- The engine will resume when the `play()` function is called (which sets the flag back to `true`).
- Stop allows time changes via events and the `gotoFrame(TAG)` function.

**Button example:**
```
p Button
  t stop[0]
```
Here the Piece freezes at frame 0. Even if the mouse forces a `gotoFrame(1)`, the engine remains stopped (`running` is still `false`) on frame 1.

---

### What -this clarifies about the global structure

By defining `stop` as a flag modifier, we resolve a major ambiguity:

1. **Passive movement:** Navigation within a stopped timeline (buttons, selectors, pages) is possible without ever restarting the engine.
2. **Active movement:** `stop` marks the end of an animated sequence (a transition, explosion, appearance) which, once complete, should no longer consume interpolation computation resources.

---

### The three tracks together — the button

The canonical example combining all three:

```
p Button
  t stop[0]
  t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
  t face[0:FOut ; 1:FOver ; 2:FPushed]
  f FOut    image "btn_out.png"
  f FOver   image "btn_over.png"
  f FPushed image "btn_pushed.png"
```

- `tag` names the three states
- `stop` freezes the timeline — no automatic animation here
- `face` switches the appearance accordingly

Each track does its job. None of them knows the others.

### Important
No code needs to be written here. The Tispi engine recognizes the keywords MOUSE_OUT and MOUSE_OVER. It moves the playhead on its own as soon as the mouse enters or leaves the area.

---

### What -this step adds

The Piece/Face tree is now **alive**. The structure remains the same — the strict p/f alternation has not changed. The tracks simply graft onto it, without modifying it.

---

## Simple concrete cases

The p/f alternation and the three structure tracks are now applied to real cases. Each case introduces one additional mechanism, without ever modifying the grammar.

---

### Case 1 — Rollover

Two visual states: rest and hover.

```
p Rollover
  t stop[0]
  t tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
  t face[0:FOut ; 1:FOver]
  f FOut  image "btn_out.png"
  f FOver image "btn_over.png"
```

The timeline spans 2 frames. The mouse moves the playhead to the targeted Tag.

---

### Case 2 — Button

Three states: rest, hover, click.

```
p Button
  t stop[0]
  t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
  t click[0:()=>{alert("hello word")}]
  t face[0:FOut ; 1:FOver ; 2:FPushed]
  f FOut    image "btn_out.png"
  f FOver   image "btn_over.png"
  f FPushed image "btn_pushed.png"
```

Same mechanism as rollover — one additional frame, one additional Tag, one additional Face.


### le click souris // TODO traduire en anglais avant production

Ici, le click souris est placé au temps 0, il sera donc actif tout le temps, puisqu'une key reste active jusqu'à la key suivant ou jusqu'à la fin de des pistes.



---

### Case 3 — Enriching a state

a state can contain multiple visual elements. `FOver` becomes a group-Face:

```
p Rollover
  t stop[0]
  t tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
  t face[0:FOut ; 1:FOver]
  f FOut  image "btn_out.png"
  f FOver group
    p Bg
      f F0 image "btn_over.png"
    p Label
      f F0 text "Hello"
```

The grammar does not change. `FOver` is simply a Face of type `group` — it opens a p/f subtree like any other group.

---

### Case 4 — Paginated frame

Multiple pages, navigable via Tags.

```
p Pages
  t stop[0]
  t tag[0:PAGE0 ; 1:PAGE1 ; 2:PAGE2]
  t face[0:FPage0 ; 1:FPage1 ; 2:FPage2]
  f FPage0 group
    pf Bg    : image "page0_bg.png"
    pf Label : text "Page 0"
  f FPage1 group
    pf Bg    : image "page1_bg.png"
    pf Label : text "Page 1"
  f FPage2 group
    pf Bg    : image "page2_bg.png"
    pf Label : text "Page 2"
```

Each Tag anchors a page. External navigation moves the playhead to `PAGE0`, `PAGE1` or `PAGE2`. Single-Face Pieces are compressed as `pf`.

---

### What these cases demonstrate

| Case | Mechanism introduced |
|---|---|
| Rollover | Tag + Stop + Face — the minimal form |
| Button | Extension to three states — same logic |
| Enriched state | Group-Face inside a face track |
| Paginated frame | Tags as a navigation system |

The grammar does not expand — it **composes**. Each case is a direct application of the same rules.

---

## Attributes and Constants

We have already introduced:

* **t** — for *Track*
* **f** — for *Face*

Let us now introduce two additional essential components.

---

### a — Attribute: Piece Properties

**Attributes** define the global properties of a Piece.

#### Examples

* **Comment**

  * Allows a Piece to be disabled without deleting it
  * Not processed at run-time

  ```
  a comment
  ```

* **Transition**

  * Defines a default transition for compatible keys
  * Applies to the entire Piece

  ```
  a tr <duration>, <acceleration>, <effect>
  ```

Note ! This list is not exhaustive: additional attributes may exist depending on requirements.

---

### c — Constant

**Constants** are used to initialize reusable values.

#### Purpose

* avoid repetition
* simplify references (especially to other Pieces)
* improve performance (optimization)
#### Principle

a constant can always be replaced by its value:

* it is a **reversible optimization**
* its value can be expanded wherever it is used

#### Scope

* a constant is visible throughout the **entire branch** in which it is defined

#### Example

```
c --diapo = -this; 
c --diapoModele = -this.modele;
```

* `-this` is a system keyword
* it refers to the **current Piece** (the one that defines the constant)

Example use case:
define a *PAGES* group as a constant to access it easily, for instance when emitting tags.

### Key Takeaways

* **a**: defines global behavior (properties)
* **c**: factors and optimizes values
* **t / f**: structure content and states
* **m**: Local module declaration (see: ia_agent_b_modules.md)

---

## Nesting via group-Face

The group-Face is the **sole composition mechanism** in Tispi. It allows Pieces to be nested inside a Face, creating a subtree that obeys the same p/f rules.

---

### The principle

a Face of type `group` contains Pieces. Those Pieces contain Faces. Those Faces can themselves be groups — and so on, with no depth limit.

```
p Root
  f F0 group
    p ChildA
      f F0 image "img.png"
    p ChildB
      f F0 group
        p GrandChild
          f F0 text "Hello"
```

The p/f alternation is recursive. The grammar does not change, regardless of depth.

---

### Simultaneous coexistence

All Pieces in a group are **simultaneously present** — -this is the Space container. They display together, each independent.

```
p Scene
  f F0 group
    p Background
      f F0 image "bg.png"
    p Title
      f F0 text "Welcome"
    p Button
      t stop[0]
      t tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
      t face[0:FOut ; 1:FOver]
      f FOut  image "btn_out.png"
      f FOver image "btn_over.png"
```

`background`, `title` and `button` coexist. Each lives in its own control space.

---

### The local timeline

Each group-Face creates an **independent timeline** for the Pieces it contains. Timelines do not know each other — they cannot interfere.

This makes it possible to nest a button inside an animation without synchronization conflicts:

```
p Anim
  t stop[0 ; 100]
  t pos[0: 0 0 ; 100: 500 300]
  f F0 group
    p Img
      f F0 image "img.png"
    p Isolation
      f F0 group
        p Button
          t stop[0]
          t tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
          t face[0:FOut ; 1:FOver]
          f FOut  image "btn_out.png"
          f FOver image "btn_over.png"
```

`p Anim` progresses from 0 to 100. `p Button` lives in its own group — its timeline from 0 to 1 is completely isolated. Switching to `MOUSE_OVER` does not disturb the animation.

---

### The composition rule

a single rule governs everything:

> To make multiple Pieces coexist, place them in a group-Face.
> To isolate a timeline, encapsulate in an additional group.

---

### What composition provides

| Need | Solution |
|---|---|
| Multiple elements visible together | Group-Face containing multiple Pieces |
| Independent subtree | Group-Face as a new context |
| Isolated timeline | Encapsulation in a dedicated group |
| Unlimited depth | Natural p/f recursion |

The power of the model lies entirely in -this single mechanism. There is no other.

---

## Timeline Isolation

Each group-Face creates a **local timeline** for the Pieces it contains. This is a direct consequence of composition — and a critical rule to avoid synchronization conflicts.

---

### The problem

Without Isolation, two Pieces with different timelines share the same temporal context. They collide.

```
p Anim
  t stop[0]
  t face[0:F0 ; 50:F1]
  t pos[0: 0 0 ; 100: 500 300]
  f F0 image "img.png"
  f F1 group
    p Button
      t stop[0]
      t tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
      t face[0:FOut ; 1:FOver]
      f FOut  image "btn_out.png"
      f FOver image "btn_over.png"
```

**The conflict**: when the mouse switches to `MOUSE_OVER`, the button's playhead moves to frame 1. But `p Anim` shares -this timeline — it is pulled back to frame 1 as well. The animation restarts from zero.

---

### The cause

`p Button` is directly inside `p Anim`'s group. They share the same timeline. Any playhead movement inside the button affects the parent animation.

---

### The solution — encapsulate

Simply wrap the button in its own group. That group creates a local, fully sealed timeline.

```
p Anim
  t stop[0]
  t pos[0: 0 0 ; 100: 500 300]
  f F0 group
    p Img
      f F0 image "img.png"
    p Isolation
      f F0 group
        p Rollover
          t stop[0]
          t tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
          t face[0:FOut ; 1:FOver]
          f FOut  image "btn_out.png"
          f FOver image "btn_over.png"
```

`p Isolation` carries a group-Face — it opens a new temporal context. The button's timeline lives inside it. It can no longer reach `p Anim`'s timeline.

---

### The rule

> Any Piece that has its own temporality must be encapsulated in its own group.

---

### What happens at each level

```
p Anim          ← timeline 0..100   (position animation)
  f F0 group
    p Img       ← no own timeline, follows parent
    p Isolation ← encapsulation point
      f F0 group
        p Button  ← timeline 0..1   (mouse states)
```

Each group is a **temporal boundary**. What happens inside does not cross that boundary.

---

### What -this step reveals

Isolation is not an additional mechanism — it is a **natural property** of the group-Face. It already exists in composition. It simply needs to be used consciously, whenever a Piece has its own temporal logic.

| Situation | Action |
|---|---|
| Piece without its own timeline | No encapsulation needed |
| Piece with independent timeline | Encapsulate in a dedicated group |
| Synchronization conflict | Look for the missing group |

---