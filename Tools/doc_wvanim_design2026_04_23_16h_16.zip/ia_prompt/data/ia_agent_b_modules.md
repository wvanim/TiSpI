# introduction

Is this information worth sharing?

the "comment" flag for a piece, added in 2007
---
Role of the "comment" flag: prevent the piece from being sent to the run-time. The piece stays in the editor.
Consequence:
The piece's action can be used for the editor itself => it becomes a macro-piece... A control, in fact.
Since the piece is in a group, we can assign a role to the group. Example: button.
The tree is modular, so we can move the entire branch of this group + the macro-pieces will follow since they are part of the tree branch.
=> export => place in an online library.
=> the comment flag, by itself, created the mechanism for building parameterizable library templates.
Some actions will allow automatic editing of a sub-group.
Example for the "animated button" template => 3 buttons will allow direct editing of each group for each button state.
I was already exporting groups from the start. I quickly understood the tree was modular. So macro-pieces followed naturally in 2007.

# Optimization through modules

A recurring subtree can be **encapsulated** as a module. The module exposes a declared interface — its parameters — and hides its internal mechanics. It behaves exactly like an ordinary Piece in the tree.

---

## The principle

**A repetitive native subtree:**

```
p Isolation
  f F0 group
    p Button
      t stop[0]
      t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
      t click[0:()=>{alert("Hello word");}]
      t face[0:FOut ; 1:FOver ; 2:FPushed]
      f FOut    image "btn_out.png"
      f FOver   image "btn_over.png"
      f FPushed image "btn_pushed.png"
```

**Becomes a module:**

```
m p ModuleButton
  doc `
    ##role
        3-state button               // informational
    ##usage 
      p <PieceName> m ModuleButton      // informational
      --click = <function>
      --mouseOut = <face>
      --mouseOver = <face>
      --mousePushed = <face>     
  `
  contract{
    timeline_isolated = true  // security
  } 
  params(
    f --mouseOut
    f --mouseOver
    f --mousePushed
  )
  modele (
    pf <PieceName> : group  // synchronization isolation group
        p Button
            t stop[0]
            t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
            t click[0:--click]
            t face[0:FOut ; 1:FOver ; 2:FPushed]
            f FOut    = --mouseOut
            f FOver   = --mouseOver
            f FPushed = --mousePushed
  )
```

The internal mechanics — tags, stop, face track, timeline isolation — are invisible. The module already knows how to handle its three states.

Note that parameters are typed. Here, Faces are expected.

**Is instantiated:**
```
p <PieceName> m ModuleButton
    --click = ((x,y, sender)=>{...}
    --mouseOut = f ...
    --mouseOver = f ...
    --mousePushed = f ...
```


## Module declaration

A module declaration is a named Piece that encapsulates a reusable subtree behind a typed parameter interface.

**Note — Modules as first-class constructs**
Modules are treated as simply as functions or classes in a programming language.
They can be:

Declared - syntax: m p <ModuleName> - defined inline during page authoring within the document structure. These modules can then be stored in libraries and imported for reuse across projects.

A module library is a collection of named module declarations. Any module in scope can be instantiated with p <PieceName> m <ModuleName> without knowledge of its internal mechanics.


### Syntax

The module declaration is introduced by m (for Module)

```
m p <ModuleName>
    doc    `<description>`           // informational — human-readable 
    contract{
        <rules>   // formal guarantees enforced by the engine
        returns {
            emits <emit_type><list returned>
        }
    }   
    params(
        <type> --<param-name>,
        ...
    )
    modele (
        <tispi-subtree using --param-name references>
    )
```
    
<description> ::= (<doc_subject> <explain>)*
<doc_subject> ::= "###role" | "###usage" | "###navigation" | "###behavior" | "###requires"
<emit_type> ::= "on success"? "on error"? "produces"? 



### Fields

| Field | Required | Role |
|---|---|---|
| `doc` | no | Human-readable description |
| `contract` | no | Formal guarantees — the engine enforces these at instantiation |
| `params` | yes | Typed input interface — defines what the caller must supply |
| `modele` | no | Internal template — the subtree the engine generates, with `--param-name` substitutions |

## Parameters

Parameters define the public interface of a module.
Each parameter is **typed**, and its type determines the nature of the expected value.

Types fall into three categories:

1. **Simple types**
2. **Indexed collections**
3. **Structural types (Piece / Face)**


### Parameter types

| Type | Description |
|---|---|
| `f` | Face — simple or group |
| `p` | Piece — complete subtree |
| `m` | Module — a complete subtree reduced to a single node |
| `bool` | Boolean value |
| `int` | Signed integer |
| `float` | Floating-point number |
| `string` | Character string |
| `color` | Color value |
| `func` | Callback function |

List non-exhaustive

A parameter name ending in `__{@frameNum}__` declares an **indexed collection** — the caller supplies `--param_3_`, `--param_9_`, etc.

#### Example

Declaration:

```
params(
  bool    --enabled
  int     --count
  float   --ratio
  string  --label
  color   --tint
  func    --click
)
```

Instantiation:

```
p <PieceName> m ModuleExample
  --enabled = true
  --count   = 3
  --ratio   = 0.75
  --label   = "Hello"
  --tint    = #FF8800
  --click   = (x,y) => { this.setPos(x,y); }
  --action  = () => { alert('Hello world'); }
```


### Indexed collections

A collection is a **repeatable** parameter, identified by an `_@index_` suffix.
The syntax requires the parameter name to end with `_@index_` in the declaration.

#### Declaration

```
params(
  f --page__{@frameNum}__
)
```

#### Instantiation

```
--page_3 = f ...
--page_9 = f ...
--page_12 = f ...
```

#### Rules

- Indexed collection indexes must be sorted in ascending order.
- Each index must be provided exactly once.
- The type of each entry must match the declared type.
- The module automatically deduces the cardinality and generates the associated internal structures (e.g. Tags, tracks, transitions).

---

### Structural types: `Piece` and `Face`

Parameters can be typed with the following structural types:

| Type | Description |
|------|-------------|
| `f` | Expects a Face (simple or group) |
| `p` | Expects a Piece (complete subtree) |

---

## Structural components of a `Piece`

Types of elements that can be declared within a `Piece`:

| Type | Description                                |
| ---- | ------------------------------------------ |
| `t`  | Declares a track                           |
| `c`  | Declares a constant initialization         |
| `f`  | Declares a Face (simple or group)          |
| `p`  | Declares a nested Piece (complete subtree) |

### Contract keys

| Key | Type | Description |
|---|---|---|
| `timeline_isolated` | bool | The module guarantees its internal timeline does not interfere with the parent |

### Instantiation syntax

```
p <InstanceName> m <ModuleName>
  --<param-name> = <value>
  ...
```

## Meta-language (modele only)

The `modele` block does not contain raw Tispi.
It uses a meta-language that is expanded into valid Tispi at instantiation.

This meta-language allows pattern expressions such as indexed expansion.

### Expansion syntax

`@name` defines an index for the Piece

`@name:<pattern>` defines an expansion over indexed parameters.

- `@name` iterates over the set of indexes extracted from the indexed parameter used in the pattern (example: `--page__{@frameNum}__`)
- The set is:
  - unique in Piece
  - sorted ascending

- The pattern is expanded by substituting `i` with each index

### Example

**Instantiation:**

--page_3 = f type ...
--page_9 = f type ...
--page_12 = f type ...

**Format:**

t tag[@index:PAGE_@index_]
t face[@index:Fpage_@index_]
f Fpage_@index_ = --page_@index_

**Expands to:**

t tag[3:PAGE_3_ ; 9:PAGE_9_ ; 12:PAGE_12_]
t face[3:Fpage_3_ ; 9:Fpage_9_ ; 12:Fpage_12_]
f Fpage_3_ = --page_3_
f Fpage_9_ = --page_9_
f Fpage_12_ = --page_12_

### Important

- This syntax is **not valid Tispi**
- It must only appear inside `modele`
- The expanded result must always be valid Tispi

### Rules

- `<moduleName>` follows variable naming rules — letters, digits, underscore only
- `<instanceName>` must be unique among sibling Pieces in its group
- All `params` entries must be supplied at instantiation
- Indexed collection indexes must be in progressive order
- The --name notation designates a named variable. A variable declared in params is a caller-supplied parameter — its value is substituted at instantiation. Other --name variables may exist as engine-produced values, internal to the module

## Common modules

**Rollover:**

```
m p ModuleRollover
  doc `
    ##role
      roll-over
      
    ##usage 
      p <PieceName> m ModuleRollover
      --mouseOut = <face>
      --mouseOver = <face>
  `    
  contract {
    timeline_isolated = true
  } 
  params {
    f --mouseOut
    f --mouseOver
  }
  modele {
    pf <PieceName> : group
        p Rollover
            t stop[0]
            t tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
            t face[0:FOut ; 1:FOver]
            f FOut    = --mouseOut
            f FOver   = --mouseOver
  }
```

**Paginated frame — variable parameter:**

We discover the template syntax for defining an expected array.

`@<var>` denotes an index variable.

- `<var>` is a user-defined name (e.g. `page`, `item`, `state`)
- At instantiation, the value of @<var> is defined by the index of the variable.

- Example:
   at declaration =>
      tags [@index: PAGE_@index_]
      params(
        f --page_@index_
      )
   at instantiation =>
      --param-9 = Type value 
      => replaces @index => tags [9: PAGE_9_]
- It is substituted by each index value during expansion

- Example in the Page module:

```
m p modulePages
  doc `
    ##role
        paginated frame
  
    ##usage
        p <PieceName> m ModulePages
            --page_<num_frame>_ = <face>
  
    ##navigation
        <piece>.sendTag(PAGE_<index>_);
  `
  contract {
    timeline_isolated = true // security
  }
  params {
    f --page_@index_
  }
  modele {
    pf <PieceName> : group
        p Pages
            t stop[0]
            t tag[@index:PAGE_@index_] // @index is unique in Piece
            t face[@index:Fpage_@index_]
            f Fpage_@index_    = --page_@index_    
  }
```

The module deduces the number of pages by counting the `--page_0_`, `--page_3_`, `--page_9_`… entries provided at usage. It automatically generates Tags `PAGE_0_`, `PAGE_3_`, `PAGE_9_`…

```
p MyPages m ModulePages
  --page_0_ = f group
    pf Bg    : image "page0_bg.png"
    pf Label : text "Page 0"
  --page_3_ = f group
    pf Bg    : image "page1_bg.png"
    pf Label : text "Page 1"
  --page_9_ = f group
    pf Bg    : image "page2_bg.png"
    pf Label : text "Page 2"
```

---

## Modules are Pieces

A module inserts into the tree exactly like an ordinary Piece. It respects the p/f alternation — it introduces no grammatical exception.

```
p MyPages m ModulePages
  --page_2_ = f group
    pf Bg    : image "page2_bg.png"
    pf Label : text "Page 2"
    p MyButton m ModuleButton
      --mouseOut    = f image "btn_out.png"
      --mouseOver   = f image "btn_over.png"
      --mousePushed = f image "btn_pushed.png"
```

`moduleButton` is directly a Piece inside `--page_2_`'s group. No wrapper Face, no intermediate group — it nests naturally.

---

## What this step provides

| Before the module | After the module |
|---|---|
| Mechanics rebuilt at every usage | Encapsulated once, reused without friction |
| Internal structure visible | Interface alone exposed |
| Possible omission errors | Behavior guaranteed by the module |

The complexity does not disappear — it moves inside the module. The usage tree remains readable, minimal, composable. This is the **@Lego** principle: autonomous bricks with a declared interface, that fit together without knowing each other.

---

## Composition by stacking

Each module is an autonomous brick, with a declared interface, that slots into the tree without friction. `moduleButton` inserts into `modulePages` like one Lego brick into another — without knowing its context, without modifying the grammar.

```
p OtherPages m ModulePages
  --page_0_ = f group
    pf Bg    : image "page0_bg.png"
    pf Label : text "Page 0"
  --page_1_ = f group
    pf Bg    : image "page1_bg.png"
    pf Label : text "Page 1"
  --page_2_ = f group
    pf Bg    : image "page2_bg.png"
    pf Label : text "Page 2"
    p OtherButton m ModuleButton
      --mouseOut    = f image "btn_out.png"
      --mouseOver   = f image "btn_over.png"
      --mousePushed = f image "btn_pushed.png"
```

---

# Decoration components — draft

## Composite types:
x ::= float
y ::= float
l ::= float
h ::= float

fontname ::= string
tag ::= pathPiece string
color ::= #hex
size ::= number
style ::= number
 
bounds ::= "*bounds*"? // for testing
color ::= "red" | "green" | "blue" | empty // for testing
background ::= color?
textStyle ::= "*style*"? // for testing
pathPiece ::= (pathHeader "." (pieceName)*)? '.' string
pathHeader ::= "_this" | "_parent" | "_brother"
pieceName ::= string

## Faces: meta-declaration (DSL)

Faces are declared here.
New Tispi rule.

Syntax starting with d for declaration:
d f type 
    params{
      <type> <param_name>
      ...
    }
    syntax{
      f <name> <family> <attributes>
    }   

### text
  d f name text
    params {
      bounds area
      color bgColor
      textStyle textStyle
      string text
    }
    syntax {
      f <name> text (bounds* red *style*)? "text in the zone"
      Examples:
      - f Name text *bounds* red *style* "text in the zone"
      - f Name text "text in the zone"
    }

## A template

More complex to handle as a module than to use as a template.
Let us take this template and add the necessary faces and properties.
 
### Simple button
  f <PieceName> : group  // synchronization isolation
    p Background
      t stop[0]
      t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
      t click[0:<clickAction>]     
      t --<cssProperty>[
          0:<value>,[<duration>:<acceleration>,<effect>], 
          1:<value>,[<duration>:<acceleration>,<effect>], 
          2:<value>,[<duration>:<acceleration>,<effect>], 
          ]
      ...    
      f Rectangle --<cssProperty>    
    p Text 
      t --<cssProperty>[
          0:<value>,[<duration>:<acceleration>,<effect>], 
          1:<value>,[<duration>:<acceleration>,<effect>], 
          2:<value>,[<duration>:<acceleration>,<effect>], 
          ]
      ...    
      f Text --<cssProperty>...
  }

Example:
  f F0 group  // synchronization isolation
    p Background
      t stop[0]
      tr [12, easeOut, face] 
      t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
      t click[0:()=>{alert("Hello world");}]        
      t --background[0:blue; 1:cyan; 2:green]
      f F0 rectangle  --background 
    p Text
      t --textColor[0:yellow; 1:white; 2:black]
      t --style[0:normal; 1:bold; 2:italic]
      t --text[0:"goto"; 1:"in"; 2:"space"]
      f F0 text --textColor --style --text
  }



## Modules 

m p ModuleButton
  doc `
    ##role 
      3-state button               
        
    ##instantiation
      p <PieceName> m ModuleButton
        func --click = <function>
        tag --sendTag = <tag>
        f --mouseOut = <face>
        f --mouseOver = <face>
        f --mousePushed = <face>     
  `
  contract {
    timeline_isolated = true // security
  } 
  params {
    func --click
    tag --sendTag
    f --mouseOut
    f --mouseOver
    f --mousePushed
  }
  modele {
    pf <PieceName> : group  // synchronization isolation
        p Button
            t stop[0]
            t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED; 3:MOUSE_CLICK]
            t face[0:FOut ; 1:FOver ; 2:FPushed]
            t click[3:--click]
            t sendTag[3:--sendTag]
            f FOut    = --mouseOut
            f FOver   = --mouseOver
            f FPushed = --mousePushed
  }
  
_____________________________________________________________________________________
_____________________________________________________________________________________

m p ModuleRollover
  doc `
    ##role
      roll-over
      
    ##instantiation
      p <PieceName> m ModuleRollover
      --mouseOut = <face>
      --mouseOver = <face>
  `    
  contract {
    timeline_isolated = true
  } 
  params {
    f --mouseOut
    f --mouseOver
  }
  modele {
    pf <PieceName> : group
        p Rollover
            t stop[0]
            t tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
            t face[0:FOut ; 1:FOver]
            f FOut    = --mouseOut
            f FOver   = --mouseOver
  }

_____________________________________________________________________________________
_____________________________________________________________________________________

m p ModulePages
  doc `
    ##role
        paginated frame
  
    ##instantiation
        p <PieceName> m ModulePages
            f --fpage_<frameNum>_ = <face>  // <face> without leading 'f'

        f --fpage_<frameNum>_ parameter generates a Face named Fpage_<frameNum>_    
        Ex:
          Declaration
            p Album m ModulePages
              f --fpage_0_ = text "message 0"
              f --fpage_1_ = text "message 1"
              f --fpage_2_ = text "message 2"
              
    ##parameter contract
        To access a page:
            <Piece>.Fpage_<frameNum>_ 
            example: _this.album.pages.Fpage_12_
            example: _this.album.pages.Fpage_{--numPage}_
                
        Navigation:
            <piece>.pages.sendTag(PAGE_<frameNum>_);
  `
  contract {
    timeline_isolated = true
  } 
  params {
    f --fpage_{@frameNum}_
  }
  modele {
    pf <PieceName> : group
        p Pages 
            a isFaceArray 
            t stop[0]
            t tag[@frameNum:PAGE_{@frameNum}_]
            t face[@frameNum:Fpage_{@frameNum}_]
            f Fpage_{@frameNum}_ = --fpage_{@frameNum}_
    }

_____________________________________________________________________________________
_____________________________________________________________________________________

m p ModuleButtonListLine
    doc `
        ##role 
            list of buttons displayed in a row              
        ##instantiation 
            p <PieceName> m ModuleButtonListLine
                c --align = <t pos>
                func --onclick_{@posIndex}_ = <func(x, y, sender)>
                f --mouseOut_{@posIndex}_ = <face> // <face> without leading 'f'
                f --mouseOver_{@posIndex}_ = <face> // <face> without leading 'f'
                f --mousePushed_{@posIndex}_ = <face> // <face> without leading 'f'
            Example:
                pf Buttons m ModuleButtonListLine
                  c align = align[0:{@posIndex * 50} 0]
                  p Bt_0_
                    c --onclick_0_ =()=>alert("button 0");
                    f --mouseOut_0_ = text "out 0"
                    f --mouseOver_0_ = text "over 0"
                    f --mousePushed_0_ = text "pushed 0"
                  p Bt_1_
                    c --onclick_1_ =()=>alert("button 1");
                    f --mouseOut_1_ = text "out 0"
                        // note: without the following states, "out 0" naturally repeats
                        // across MOUSE_OUT => MOUSE_OVER, MOUSE_PUSHED
                    
        ##behavior
            On button click (onclick), executes the action
    `
    params {
        p --pieceBt_{@posIndex}_
        f --mouseOut_{@posIndex}_
        f --mouseOver_{@posIndex}_
        f --mousePushed_{@posIndex}_
        func --onclick_{@posIndex}_
        pos --align
    }
    modele {
        pf <IndexTab> : group 
            a isPieceArray 
            c align = --align
            p Name_{@posIndex}_ = --pieceBt_{@posIndex}_ 
                t stop[0]
                t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
                t face[0:FOut_{@posIndex}_ ; 1:FOver_{@posIndex}_ ; 2:FPushed_{@posIndex}_ ] 
                c onclick_{@posIndex}_ = --onclick_{@posIndex}_
                f FOut_{@posIndex}_    = --mouseOut_{@posIndex}_
                f FOver_{@posIndex}_   = --mouseOver_{@posIndex}_
                f FPushed_{@posIndex}_ = --mousePushed_{@posIndex}_      
    }  


---

m p moduleIndexedPages
  doc `
    ##role 
      Pages in an indexed frame              
        
    ##instantiation 
      p <PieceName> m ModuleIndexedPages
      f --imageIndex_<posIndex>_ = <face> // <face> without leading 'f'
      f --imageOver_<posIndex>_ = <face> // <face> without leading 'f'
      f --imagePushed_<posIndex>_ = <face> // <face> without leading 'f'
      f --doc_<posIndex>_ = <face> // <face> without leading 'f'

    ##parameter contract
      navigation:
        <piece>.documents.sendTag(PAGE_<posIndex>_);

    ##behavior
      On thumbnail click (MOUSE_CLICK),
      sends PAGE_<posIndex>_ to the parent → displays the corresponding document.
  `
  contract {
    timeline_isolated = true // security
  } 
  params {
    f --imageIndex_{@posIndex}_
    f --imageOver_{@posIndex}_
    f --imagePushed_{@posIndex}_
    f --doc_{@posIndex}_
  }
  modele {
    pf <PieceName>: group
        pf <IndexTab> : group 
          a isPieceArray 
            pos=pos[0:{@posIndex * 50} 0]
        
          m p moduleIcon   // Multiple Pieces displayed
            doc `
                ##role 
                3-state button               
                    
                ##usage 
                p <PieceName> m ModuleIcon
                  c --sendTag = <tag>
                  f --mouseOut = <face>  // <face> without leading 'f'
                  f --mouseOver = <face> // <face> without leading 'f'
                  f --mousePushed = <face>   // <face> without leading 'f'   
            `
            contract {
                timeline_isolated = true // security
            } 
            params {
                tag --sendTag
                f --mouseOut
                f --mouseOver
                f --mousePushed
            }
            modele {
                pf <PieceName> : group  // synchronization isolation
                    p Button
                        t stop[0]
                        t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
                        t face[0:FOut ; 1:FOver ; 2:FPushed ]  
                        t sendTagClick[0:--sendTag]
                        f FOut    = --mouseOut
                        f FOver   = --mouseOver
                        f FPushed = --mousePushed
            }
          p Index_{@posIndex}_ m ModuleIcon
            c --sendTag = _parent._parent.documents PAGE_{@posIndex}_
            f --mouseOut  = --imageIndex_{@posIndex}_
            f --mouseOver  = --imageOver_{@posIndex}_
            f --mousePushed = --imagePushed_{@posIndex}_

        p Documents m ModulePages
          f --fpage_{@posIndex}_ = --doc_{@posIndex}_
  }  
  
_____________________________________________________________________________________
_____________________________________________________________________________________

Reminder: 
- a single face does not need a "face track"
- a value persists until the next key. Even if it can combine with the value of the next key.
  => therefore a face remains active until the next key or until the end
  => therefore a single face is always active.


  
New features:
- variable tracks
  their name is prefixed with "--" to indicate they are variables. Ex: --text[...] 
  they describe the evolution of a variable's value along the timeline
  In the example below, the text changes at each frame in: t --text[...]  
- transition at Piece level and at key level
```
    pf MessIdentification : group
        p Pages
            a tr [0.5s, easeOut, fade]
            t stop[0]
            t tag[0:MESSAGE_IDLE ; 1:MESSAGE_OK ; 2:MESSAGE_ERROR_0; 3:MESSAGE_ERROR_1]
            t sendTag[1:_parent[PAGE_2].foo[STATE_3]]
            t --textContent[0:"waiting"; 1:"Correct, let's continue"; 2:"Error: enter username"; 3:"Error: enter secret code"]
            t --color[0:black, 1:green, 2:red, [0.5s, easeOut, explode]] // Note that red propagates up to frame 3

            f F0 text [100, 200, 400, 30] white ["Arial", 12, B, --color ] --textContent
```

_____________________________________________________________________________________
_____________________________________________________________________________________


m p ModuleRequestPHP
  doc`
    ##role
      Generic PHP request with states and temporal isolation
      
    ##instantiation 
      p <PieceName> m ModuleRequestPHP
        --url = "my_php.php"
        --params = --phpParams
        --sender = _parent.form
        --on-success = "functionOk"
        --on-error = "functionError"

    ##navigation
      <pieceRequest>.requestPhp(params);
        
    ##behavior
      requestPhp() automatically moves the playhead:
          => REQUEST_PENDING (request in progress)
          => REQUEST_OK      (success)
          => REQUEST_ERROR   (error)
    
    ##requires
      Tispi.phpRequest(--url, --params)
  `
  
  contract {
    timeline_isolated = true
    returns {
      emits on success: sender.receivePhp(--on-success, --message) // cf. --message received with produces
      emits on error:   sender.receivePhp(--on-error, --message)
      produces: --message (filled by PHP echo)
    }
  }
  params {
    string --url
    array --params
    p --sender
    func --on-success
    func --on-error
  }   
  
  modele {
    p <PieceName> // synchronization isolation
      c --requestPhp = ()=>{_this.request.sendTag(REQUEST_IDLE)}          
      f F0 group 
        p Request
          t stop[0]
          t tag[0:REQUEST_WAIT; 1:REQUEST_IDLE; 2:REQUEST_PENDING ; 3:REQUEST_OK ; 4:REQUEST_ERROR]
          t face[2:FPending ; 3:FOk ; 4:FError]
          t sendTag[
            3:--sender --on-success --message, _this REQUEST_WAIT;
            4:--sender --on-error --message, _this REQUEST_WAIT
          ]
          t action[
            1: Tispi.io.phpRequest(_this, --url, --params) ;
          ]
          
          f FPending text "Request in progress…"
          f FOk text ""
          f FError text ""
  }

# The structural importance of the sendTag track

sendTag is the canonical representation of state machine transitions in Tispi, enabling a fully deterministic and statically analyzable evolution.

---

## Correct reformulation of `t sendTag`

### Principle

> **A value of `sendTag` is a sequence of tags to send.**

No structural distinction:

* ❌ not "external emission vs local action"
* ✔ solely a **list of tag sends**

---

## 1. Example walkthrough

```tispi
t sendTag[
  3:--sender --on-success --message, _this REQUEST_WAIT;
  4:--sender --on-error --message, _this REQUEST_WAIT;
]
```

---

## 2. Correct decomposition

Each keyframe contains:

```text
frame : sendTag, sendTag, ...
```

---

### 2.1 A `sendTag`

General form:

```text
<target> <tag> [parameters...]
```

---

### 2.2 Application to this case

#### First instruction

```tispi
--sender --on-success --message
```

→ tag send:

* target: `--sender`
* tag: `--on-success`
* parameter: `--message`

---

#### Second instruction

```tispi
_this REQUEST_WAIT
```

→ tag send:

* target: `_this`
* tag: `REQUEST_WAIT`
* no parameter

---

## 3. Simplified syntax

```ebnf
sendTag ::= send (',' send)* ;

send ::= target tag (value)*
```

---

## 4. Nature of the mechanism

`sendTag` is therefore:

> **a declarative track for sending tags to targets**

Each entry:

* does not describe an action
* does not describe logic
* describes only **sends**

---

## 5. Important property

Unlike `action`:

* `action` → executes code
* `sendTag` → **declares transitions / notifications**

---

## 6. Conceptual consequence

This formulation enforces a purer reading of the model:

> The system does not "perform actions"
> It **propagates states (tags)**

---

## 7. Final summary

✔ A `sendTag` keyframe = list of tags to send
✔ Each element = `target + tag + optional parameters`
✔ No notion of "block"
✔ No internal hierarchy

---

## Clean formulation

> **`t sendTag` is a track that describes, for each frame, a list of tags to send to given targets, optionally accompanied by parameters.**

## Classic Tispi pitfalls

- Forgetting that modules are Pieces

- Wrong parameter type in a module:
The Tispi engine checks whether a parameter has the wrong type in a module.

# Extended Tispi rules
- Reserved path heads:
    _this    : refers to the current Piece
    _parent  : refers to the parent Piece
    _brother : refers to the space of sibling Pieces in the current group
    
    Syntax:
    <path> ::= _this
            | _parent
            | _brother.<PieceName>
            | <path>.<PieceName>
            | <path>.<propertyName>
    
    Rules:
    - A contextual path must start with a reserved path head.
    - `_brother` must always be followed by the name of a sibling Piece.
    - Reserved path heads cannot be used as Piece names.
    - Reminder: a referenced sibling Piece must exist and be uniquely identified within its parent Face group.
    
- @frameNum: refers to the current index of the Piece
    Meta variable available only in module definitions
    - @<path>.index
      Reference to the index of another Piece.
      Usable in any modele nested within an indexed module.
      Example: 
        {@_parent.index} = reference to the index of the parent Piece
        {@pieceName.index} = reference to a Piece named pieceName

- Naming convention:
    | Element | Form | Example |
    |---|---|---|
    | Author variable | `--camelCase` | `--numPage`, `--mouseOut` |
    | Placeholder | `@camelCase` | `@frameNum`, `@parentIndex` |
    | Indexed node | `Name_{@frameNum}_` | `Fpage_{@frameNum}_` → `Fpage_12_` |
    | System tag | SCREAMING_SNAKE | MOUSE_OUT, MOUSE_OVER |
    | Indexed tag | NAME_{@frameNum}_ | PAGE_{@frameNum}_ → PAGE_12_ |

- {}: required for any variable inserted in a node name,
  a literal, or a computed expression.
  
  | Context | Notation | Example |
  |---|---|---|
  | Computed expression | `{}` | `{@frameNum * 50}` |
  | Variable in a name | `{}` | `Fpage_{@frameNum}_` |
  | Author variable in a name | `{}` | `Fpage_{--numPage}_` |
  | Simple reference outside a name | without `{}` | `--var`, `@frameNum` |  

- a isFaceArray: Piece attribute — indicates that the Piece
  contains an expandable indexed collection of Faces.
  The engine generates one Face instance per @index found
  in params of type f --Name_{@index}_. 

- a isPieceArray: Face attribute — indicates that the Face
  contains an expandable collection of Pieces.
  Non-structural — description optimization only.
  Available properties:
    pos = pos[0:{@index * 50} 0]  // position computed by index 

- tag: "tag" type for a variable
  tag ::= pathPiece string
  pathPiece ::= (pathHeader "." (pieceName)*)? '.' string
  pathHeader ::= "_this" | "_parent" | "_brother"
  pieceName ::= string

- @posIndex: system meta-variable available in module definitions.
  Refers to the current frame number in the indexed expansion context.

- A module declared in a modele is local to that modele.
  It is not accessible from outside the parent module.
  Its scope is limited to the branch in which it is declared. 

- onclick is a reserved Tispi keyword — if present => replaces t click[]

- Substitution principle
  In a modele, any value can be replaced by a parameter:
  f <name> = --<param>    // Face substitution
  p <name> = --<param>    // Piece substitution
  c <name> = --<param>    // constant substitution
  t <name> = --<param>    // track substitution

  The mechanism is identical regardless of type.
  `= --param` means: replace this node with the value supplied at instantiation.

  No exception — if a substitution does not work on a type,
  it is an incomplete rule or a missing concept.
