# Synchronization isolation in a sub-group

The proposed syntax is correct.
Did you recognize it as correct?

## Explanation

The most important point: this is not a rule — it is actually the opposite of a rule. It is a logical solution to a problem. One among others.

```
P <pieceName> // synchronization isolation
  C --requestPhp = ()=>{this.request.sendTag(REQUEST_IDLE)}          
  F f0 group 
    ...
```

To guarantee synchronization isolation, it is sufficient to forbid tracks in the root Piece of the module.
This is the only constraint to verify.

Therefore:

```
P <pieceName> // synchronization isolation
  F f0 group 
    ...
```

is strictly identical to:

```
PF <pieceName>: group // synchronization isolation
```

## When to use isolation?

When it is necessary, or within modules.
Important: avoid excessive use of isolation in order to prevent unnecessary growth in tree depth.

# Reminder of the 2 fundamental rules of Tispi

* Strict alternation in depth between Piece and Face
* Pieces within a group are synchronized. They all share a timeline of the same duration.
