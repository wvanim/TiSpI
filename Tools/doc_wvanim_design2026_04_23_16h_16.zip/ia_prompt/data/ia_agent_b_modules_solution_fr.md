# L'isolation synchro dans un sous-groupe

La syntaxe proposée est correcte. 
L'aviez vous reconnue comme correcte ?

## Explication

Le point le plus important : ce n'est pas une règle, c'est même l'opposé d'une règle, c'est une solution logique à un problème. Une parmis d'autres.

```
    P <pieceName> // isolation synchronique
      C --requestPhp = ()=>{this.request.sendTag(REQUEST_IDLE)}          
      F f0 group 
        ...
```

Pour garantir l'isolation synchronique, il suffit d'interdire les Pistes dans dans la Piece racine du module.
C'est la seul contrainte à vérfier

Donc :

```
    P <pieceName> // isolation synchronique
      F f0 group 
        ...
``` 

est absolument identique à 

```
    PF <pieceName>: group // isolation synchronique
``` 

## Quand utiliser l'isolation ?

Quand elle est nécessaire, ou pour dans modules.
Important : éviter l'usage intempestif de l'isolation afin d'éviter d'accumuler de la profondeur de l'arbre. 

# Rappel des 2 règles fondamentales de Tispi

- Alternance stricte en profondeur de Piece et de Face
- les pièces d'un groupe sont synchronisées. Elles possèdent toutes un barre de temp de même durée.