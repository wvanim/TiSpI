Fichier : ia_agent_b_module_deco.md

# Decoration modules

This final optimization step specializes modules for a particular context.

The modules covered so far offer branch reductions.
Decoration modules are limited to applying predefined values
to the variables of their targets.

Two use cases:
- **Structural module**: the decoration module encapsulates an existing module
  by fixing some of its values.
- **Simple node**: the decoration module instantiates a single node
  with predefined properties — a node being a branch reduced
  to its simplest expression.

The mechanism is identical in both cases — only the depth of the target varies.

## Exercise — `modulePageDecorated`

A module that encapsulates `modulePages` by adding a common decoration to all pages.

---

## Principle

```
m p PagesOfBranch m ModulePages 
  doc `
    ##role
        paginated frame
  
    ##instantiation
        p <PieceName> m ModulePages
            f --fpage_<frameNum>_ = <face>  // <face> without leading 'f'

        f --fpage_<frameNum>_ parameter generates a Face named Fpage_<frameNum>_    
        Ex:
          Declaration
            p Album m ModulePages
              f --fpage_0_ = text "message 0"
              f --fpage_1_ = text "message 1"
              f --fpage_2_ = text "message 2"
          access
            <Piece>.Fpage_<frameNum>_ 
            example: _this.album.pages.Fpage_12_
            example: _this.album.pages.Fpage_{--numPage}_                
  `
  contract {
    timeline_isolated = true
  } 
  params {
    rectangle --colorFond_{@frameNum}_
    pf image --image_{@frameNum}_
  }
  modele {
    pf <PieceName> : group
        p Pages 
            a isFaceArray 
            t stop[0]
            t tag[@frameNum:PAGE_{@frameNum}_]
            t face[@frameNum:Fpage_{@frameNum}_]
            f Fpage_{@frameNum}_ = group
              pf Rectangle --colorFond_{@frameNum}_
              pf Image --image_{@frameNum}_
    }
```

---

```
m p ModulePageDecorated
  doc `
    ##role
      paginated frame with common decoration
    ##instantiation
      p <PieceName> m ModulePageDecorated
        c --shadowColor = #333
        c --borderRadius = 8
        color --bgColor_<posIndex>_ = <color>
        f --content_<posIndex>_ = <face>
  `
  params {
    color --shadowColor
    int   --borderRadius
    color --bgColor_{@posIndex}_
    f     --content_{@posIndex}_
  }
  modele {
    p <PieceName> m ModulePages
      f --fpage_{@posIndex}_ = group
        pf Frame
          a shadow --shadowColor
          a borderRadius --borderRadius
          f F0 group
            pf Bg : rect --bgColor_{@posIndex}_
            p Content
              f F0 = --content_{@posIndex}_
  }
```

---

## What the sub-module provides

| Responsibility | Owner |
|---|---|
| Pagination, tags, isolation | `modulePages` |
| Frame, shadow, border-radius | `modulePageDecorated` |
| Background color per page | parameter `--bgColor_{@posIndex}_` |
| Content per page | parameter `--content_{@posIndex}_` |

---

## Instantiation

```
p MyPages m ModulePageDecorated
  c --shadowColor = #333
  c --borderRadius = 8
  color --bgColor_0_ = #FF0000
  color --bgColor_1_ = #00FF00
  color --bgColor_2_ = #0000FF
  f --content_0_ = text "Page 0"
  f --content_1_ = text "Page 1"
  f --content_2_ = text "Page 2"
```

---

Here is a concrete instance — a gallery of 3 products with 2 views each:

```
p Gallery m ModuleIndexedPages
  f --imageIndex_0_ = image "thumb_product1.png"
  f --imageOver_0_  = image "thumb_product1_over.png"
  f --imagePushed_0_ = image "thumb_product1_over.png"
  f --doc_0_ = group
    pf View  : image "product1_full.png"
    pf Label : text "Product 1"

  f --imageIndex_1_ = image "thumb_product2.png"
  f --imageOver_1_  = image "thumb_product2_over.png"
  f --imagePushed_1_ = image "thumb_product2_over.png"
  f --doc_1_ = group
    pf View  : image "product2_full.png"
    pf Label : text "Product 2"

  f --imageIndex_2_ = image "thumb_product3.png"
  f --imageOver_2_  = image "thumb_product3_over.png"
  f --imagePushed_2_ = image "thumb_product3_over.png"
  f --doc_2_ = group
    pf View  : image "product3_full.png"
    pf Label : text "Product 3"
```

---

## External navigation

```
_this.gallery.documents.sendTag(PAGE_0_)
_this.gallery.documents.sendTag(PAGE_1_)
_this.gallery.documents.sendTag(PAGE_2_)
```

## Expanded tree

```
p Gallery
  f F0 group                           // pf <PieceName> : group
    pf IndexTab : group                // pf <indexTab> : group
      p Index_0_         // m ModuleIcon from expansion @posIndex = 0
        f F0 group
          p Button
            t stop[0]
            t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
            t face[0:FOut ; 1:FOver ; 2:FPushed]
            t sendTagClick[0: _parent._parent.documents PAGE_0_]
            f FOut    image "thumb_product1.png"
            f FOver   image "thumb_product1_over.png"
            f FPushed image "thumb_product1_over.png"
      p Index_1_         // m ModuleIcon from @posIndex = 1
        f F0 group
          p Button
            t stop[0]
            t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
            t face[0:FOut ; 1:FOver ; 2:FPushed ]
            t sendTagClick[0: _parent._parent.documents PAGE_1_]
            f FOut    image "thumb_product2.png"
            f FOver   image "thumb_product2_over.png"
            f FPushed image "thumb_product2_over.png"
      p Index_2_         // m ModuleIcon from @posIndex = 2
        f F0 group
          p Button
            t stop[0]
            t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
            t face[0:FOut ; 1:FOver ; 2:FPushed ]
            t sendTagClick[0: _parent._parent.documents PAGE_2_]
            f FOut    image "thumb_product3.png"
            f FOver   image "thumb_product3_over.png"
            f FPushed image "thumb_product3_over.png"
    p Documents                        // p Documents m ModulePages expanded
      f F0 group
        p Pages
          t stop[0]
          t tag[0:PAGE_0_ ; 1:PAGE_1_ ; 2:PAGE_2_]
          t face[0:Fpage_0_ ; 1:Fpage_1_ ; 2:Fpage_2_]
          f Fpage_0_ group
            pf View  : image "product1_full.png"
            pf Label : text "Product 1"
          f Fpage_1_ group
            pf View  : image "product2_full.png"
            pf Label : text "Product 2"
          f Fpage_2_ group
            pf View  : image "product3_full.png"
            pf Label : text "Product 3"
```

---

## What the expansion produced

| Source | Result |
|---|---|
| `@posIndex` = 0,1,2 | 3 instances of `p Index_x_` + 3 Faces `Fpage_x_` |
| `c --sendTag` | `t sendTagClick[0: _parent._parent.documents PAGE_x_]` |
| `f --doc_x_` | `f Fpage_x_ group ...` |
| `modulePages` | `t tag`, `t stop`, `t face` generated automatically |
