**règles structurantes fondamentales** de Tispi

---

# 1. Invariant principal : alternance p / f

> **La structure est un arbre strictement alterné Piece / Face**

```tispi
p → f → p → f → ...
```

### Interdictions

* ❌ `p` dans `p`
* ❌ `f` dans `f` (sauf via `group` qui reste une Face)

---

# 2. Règle de composition unique

> **Seul un `f group` peut contenir des Pieces**

```tispi
f F0 group
  p ChildA
  p ChildB
```

➡️ Aucun autre mécanisme de nesting n’existe.

---

# 3. Séparation structure / temps

> **La structure (p/f) est indépendante de la timeline (tracks)**

* Structure = arbre
* Temps = tracks attachées aux Pieces

```tispi
p A
  t face[...]
  f F0 ...
```

➡️ Les tracks **référencent**, elles ne définissent pas la structure.

---

# 4. Localisation des tracks

> **Les tracks appartiennent uniquement aux Pieces**

* ✔ autorisé :

```tispi
p A
  t face[...]
```

* ❌ interdit :

```tispi
f F0
  t face[...]   // invalide
```

---

# 5. Nature du temps

> **Le temps est continu par défaut**

> **Les keys introduisent des ruptures**

Conséquences :

* une valeur reste active jusqu’à la suivante
* une key absente ≠ vide
* une key absente = continuité

---

# 6. Rôle du `t face`

> **`t face` sélectionne la Face active dans le temps**

* une seule Face active à un instant donné
* les autres n’existent pas à cet instant

---

# 7. Rôle du `f group`

> **Un group crée un espace de coexistence**

* toutes les Pieces sont actives simultanément
* indépendance spatiale

---

# 8. Isolation temporelle

> **Chaque `f group` définit un contexte temporel local**
> **Les Pieces de premier niveau dans un même group, partageant le même playhead, sont synchronisées

Règle :

> toute logique temporelle autonome doit être encapsulée dans un group

---

# 9. Indépendance des tracks

> **Chaque track est autonome**

* `face`, `tag`, `stop`, `pos`, `sendTag`, etc.
* aucune dépendance implicite entre elles

---

# 10. `stop` comme contrôle moteur

> **`stop` n’est pas une valeur temporelle, mais un état moteur**

* arrête le playhead
* ne bloque pas `gotoFrame`

---

# 11. `tag` comme adressage

> **Un tag est un état, pas une action**

* navigation via `gotoFrame(Tag)`
* aucune logique embarquée

---

# 12. `sendTag` comme propagation d’état

> **Le système ne fait pas des actions, il propage des états**

```tispi
t sendTag[
  frame : target tag (params)
]
```

---

# 13. Variables temporelles

> **Les variables (`--x`) sont pilotées comme des tracks**

* même syntaxe
* aucune influence structurelle

---

# 14. Compression sans perte

> ** une Piece-Face `pf` est une compression structurelle réversible**

```tispi
pf A : image "..."
```

≡

```tispi
p A
  f F0 image "..."
```

---

# 15. Modules = générateurs de structure

> **Un module produit un sous-arbre valide**

* respecte toutes les règles précédentes
* peut être paramétré

---

# 16. Injection contrôlée (modules)

> **Les modules peuvent injecter des Faces ou des Pieces via paramètres**

* noms indexés (`@index`)
* cohérence structure ↔ tracks

---

# 17. Résolution tolérante

> **Une référence absente ne provoque pas d’erreur**

* elle est ignorée
* la timeline se résout par continuité

---

# 18. Unicité des noms

> **Dans un même scope :**

* Pieces sœurs → noms uniques
* Faces d’un Piece → noms uniques

---

# 19. Attributs de Pieces

> **Les attributs (`a`) définissent le comportement global d'une Piece.**
* Ils s'appliquent à l'ensemble de la Piece, indépendamment des tracks.
* Ils ne modifient pas la structure p/f.


---

# Synthèse

Tispi repose sur 4 axes fondamentaux :

### 1. Structure

* alternance p/f
* group = seul mécanisme

### 2. Temps

* continu
* keys = ruptures

### 3. Séparation

* structure ≠ timeline
* tracks ≠ structure

### 4. Propagation

* pas d’actions → états propagés (`tag`, `sendTag`)

---

# Formulation condensée

> Tispi est un arbre p/f invariant,
> piloté par des timelines indépendantes,
> où le temps est continu,
> et où les transitions sont décrites par propagation d’états.

---






