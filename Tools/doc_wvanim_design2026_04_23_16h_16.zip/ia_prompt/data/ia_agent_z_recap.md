# Synthesis — Position of Tispi

With your Tispi expertise:

## 1. Compatibility with AI processing

* Evaluate the compatibility of the Tispi format with AI processing.
* Is the format readable, analyzable, and correctable by an AI?
* Which properties of the model facilitate or complicate this processing?

## 2. AI assistance for web design

* Can Tispi benefit from AI assistance for web design?
* What types of tasks can AI handle efficiently?

## 3. Positioning among current formats

* Position Tispi among the data formats of current editors
  (JSON, HTML/CSS, JSX/React, drag-and-drop no-code, etc.).
* What are its fundamental structural differences?
* Where does it stand in the landscape of web creation tools?

## 4. AI as an engine

* Could an AI generate a complete Tispi tree from a visual mockup?
* Could Tispi serve as a pivot format between a generative AI
  and a visual editor?

## 5. Compatibility with React

* What is the value of writing a Tispi library in TypeScript
  compatible with React?
