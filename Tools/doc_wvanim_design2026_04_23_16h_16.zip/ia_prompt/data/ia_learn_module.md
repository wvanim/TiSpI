Pour votre expertise en Temps/Espace Innvariant (Tispi) voici des exemples de modules que nous utiliserons pous votre entrainement

Veuillez vérifier leur validité pour le langage et le fonctionnement Tispi 



# Les outils pour l'entrainement Tispi-structure

## Les type composites :
x ::= float
y ::= float
l ::= float
h ::= float

fontname ::=string
color ::= #hex
size ::= number
style ::= number
 
bounds ::= "*bounds*"? // pour test
color ::= "red" | "green" | "blue" | vide // pour test 
background ::= color?
textStyle ::= "*style*"? // pour test

## Faces : méta-déclaration (DSL)

Ici nous déclarons les Faces
Nouvelle règle Tispi.

Syntaxe commençant par D comme déclaration
D F type 
    params{
      <type> <param_naame>
      ...
    }
    syntaxe{
      F <name> <family> <attributes>
    }   

### text
  D F name text
    params {
      bounds area
      color bgColor
      textStyle textStyle
      string text
    }
    syntaxe {
      F <name> text (bounds* red *style*)? "texte dans la zone"
      Examples:
      - F name text *bounds* red *style* "texte dans la zone"
      - F name text "texte dans la zone"
    }

### Image
  D F name image
    params {
      string path
    }
    syntaxe {
      F <name> image (bounds*)? ""url/image.png"
      Examples:
      - F myimage image *bounds* "url/image.png"
      - F myimage image "url/image.png"

## Les modules 

M P moduleButton
  doc `
    ##role 
      3-state button               
        
    ##usage 
      P <pieceName> M moduleButton
      --click = <function>
      --mouse-out = <face>
      --mouse-over = <face>
      --mouse-pushed = <face>     
  `
  contract {
    timeline_isolated = true // security
  } 
  params {
    func --click
    F --mouse-out
    F --mouse-over
    F --mouse-pushed
  }
  modele {
    PF <pieceName> : group  // isolation synchro
        P button
            T tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
            T stop[0]
            T face[0:fOut ; 1:fOver ; 2:fPushed]
            T click[0:--click]
            F fOut    = --mouse-out
            F fOver   = --mouse-over
            F fPushed = --mouse-pushed
  }
_____________________________________________________________________________________
_____________________________________________________________________________________

M P moduleRollover
  doc `
    ##role
      roll-over
      
    ##usage 
      P <pieceName> M moduleRollover
      --mouse-out = <face>
      --mouse-over = <face>
  `    
  contract {
    timeline_isolated = true
  } 
  params {
    F --mouse-out
    F --mouse-over
  }
  modele {
    PF <pieceName> : group
        P rollover
            T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
            T stop[0]
            T face[0:fOut ; 1:fOver]
            F fOut    = --mouse-out
            F fOver   = --mouse-over
  }
_____________________________________________________________________________________
_____________________________________________________________________________________

M P modulePages
  doc `
    ##role
        cadre paginé
  
    ##usage
        P <pieceName> M modulePages
            --page-<num_frame> = <face>
  
    ##navigation
        <piece>.sendTag(PAGE_<index>);
  `
  contract {
    timeline_isolated = true
  } 
  params {
    F --page-@index
  }
  modele { // Notez la Syntaxe de tableau de valeur
    PF <pieceName> : group
        P pages
            T tag[@index:PAGE_@index] // @index is unic in Piece
            T stop[0]
            T face[@index:fpage_@index]
            F fpage_@index    = --page-@index    
  }
_____________________________________________________________________________________

_____________________________________________________________________________________
_____________________________________________________________________________________

Rappel : 
- une face unique n'a pas besoin de "piste face"
- un valeur reste présente jusqu'à la key suivante. Même si elle peut se combiner avec la valeur de la keys suivante.
  => donc une face restera active jusqu'à la key suivant ou jusqu'à la fin
  => donc une face unique est toujours active.


  
Nouveauté :
- les pistes de variables
  leur nom est précédé de "--" pour indiquer qu'il sagit de variable. Ex : --text[...] 
  elle indique 'évolutionde la valeur d'une variable dans une piste de la barre de temps
  Dans l'exemple ci-dessous, les texte change à chaque temps dans : T --text[...]  
- transition au niveau de la Piece, et au niveau de la key
```
    PF messIdentification : group
        P pages
            tr : [0.5s, easeOut, fade]
            T tag[0:MESSAGE_IDLE ; 1:MESSAGE_OK ; 2:MESSAGE_ERROR_0; 3:MESSAGE_ERROR_1]
            T stop[0]
            T sendTag[1:_parent[PAGE_2].foo[STATE_3]]
            T --textContent[0:"en attente"; 1:"Correct, continuons"; 2:"Erreur entrez le pseudo"; 3:"Erreur entrez le code-secret"]
            T --color[0:black, 1:green, 2:red, [0.5s, easeOut, explode]] // Notez qe red se propage jusqu-à la frame numéro 3

            F f0 text [100, 200, 400, 30] white ["Arial", 12, B, --color ] --textContent
```

_____________________________________________________________________________________
_____________________________________________________________________________________


M P moduleRequestPHP
  doc`
    ##role
      Requête PHP générique avec états et isolation temporelle
      
    ##usage
      P <pieceName> M moduleRequestPHP
        --url = "my_php.php"
        --params = --phpParams
        --sender = this._parent.form
        --on-success = "functionOk"
        --on-error = "functionError"

    ##navigation
      <pieceRequest>.requestPhp(params);
        
    ##behavior
      requestPhp() déplace automatiquement le playhead :
          => REQUEST_PENDING (requête en cours)
          => REQUEST_OK      (succès)
          => REQUEST_ERROR   (erreur)
    
    ##requires
      Tispi.phpRequest(--url, --params)
  `
  
  contract {
    timeline_isolated = true
    returns {
      emits on success: sender.receivePhp(--on-success, --message) // cf. --message received with produces
      emits on error:   sender.receivePhp(--on-error, --message)
      produces: --message ( fill by echo of PHP)
    }
  }
  params {
    string --url
    array --params
    P --sender
    func --on-success
    func --on-error
  }
  modele {
    P <pieceName> // isolation synchronique
      V --requestPhp = ()=>{this.request.sendTag(REQUEST_IDLE)}          
      F f0 group 
        P request
          T tag[0:REQUEST_WAIT; 1:REQUEST_IDLE; 2:REQUEST_PENDING ; 3:REQUEST_OK ; 4:REQUEST_ERROR]
          T stop[0]
          T face[2:fPending ; 3:fOk ; 4:fError]
          T sendTag[
            3:--sender --on-success --message, this REQUEST_WAIT;
            4:--sender --on-error --message, this REQUEST_WAIT
          ]
          T action[
            1: Tispi.io.phpRequest(this, --url, --params) ;
          ]
          
          F fPending text "Requête en cours…"
          F fOk text ""
          F fError text ""
  }

# Ici nous découvrons plus en détail la piste sendTag, dont l'importance est struturelle.

sendTag est la représentation canonique des transitions d’une machine à états dans Tispi, permettant une évolution entièrement déterministe et statiquement analysable.

---

## Reformulation correcte de `T sendTag`

### Principe

> **Une valeur de `sendTag` est une suite de tags à envoyer.**

Pas de distinction structurelle :

* ❌ pas “émission externe vs action locale”
* ✔ uniquement une **liste d’envois de tags**

---

## 1. Lecture de ton exemple

```tispi
T sendTag[
  3:--sender --on-success --message, this REQUEST_WAIT;
  4:--sender --on-error --message, this REQUEST_WAIT;
]
```

---

## 2. Décomposition correcte

Chaque keyframe contient :

```text
frame : tagSend, tagSend, ...
```

---

### 2.1 Un `tagSend`

Forme générale :

```text
<cible> <tag> [paramètres...]
```

---

### 2.2 Application à ton cas

#### Première instruction

```tispi
--sender --on-success --message
```

→ envoi d’un tag :

* cible : `--sender`
* tag : `--on-success`
* paramètre : `--message`

---

#### Deuxième instruction

```tispi
this REQUEST_WAIT
```

→ envoi d’un tag :

* cible : `this`
* tag : `REQUEST_WAIT`
* pas de paramètre

---

## 3. Syntaxe simplifiée

```ebnf
T sendTag[
  frame : send (',' send)* ;
]

send ::= target tag (value)*
```

---

## 4. Nature du mécanisme

`sendTag` est donc :

> **une piste déclarative d’envoi de tags à des cibles**

Chaque entrée :

* ne décrit pas une action
* ne décrit pas une logique
* décrit uniquement **des envois**

---

## 5. Propriété importante

Contrairement à `action` :

* `action` → exécute du code
* `sendTag` → **déclare des transitions / notifications**

---

## 6. Conséquence conceptuelle

Ta formulation impose une lecture plus pure du modèle :

> Le système ne fait pas “des actions”
> Il **propage des états (tags)**

---

## 7. Résumé final

✔ Une keyframe de `sendTag` = liste de tags à envoyer
✔ Chaque élément = `cible + tag + paramètres éventuels`
✔ Pas de notion de “bloc”
✔ Pas de hiérarchie interne

---

## Formulation propre

> **`T sendTag` est une piste qui décrit, pour chaque frame, une liste de tags à envoyer à des cibles données, éventuellement accompagnés de paramètres.**





 
_____________________________________________________________________________________
_____________________________________________________________________________________  
_____________________________________________________________________________________
_____________________________________________________________________________________  
_____________________________________________________________________________________
_____________________________________________________________________________________  


_____________________________________________________________________________________
_____________________________________________________________________________________  
_____________________________________________________________________________________
_____________________________________________________________________________________  
_____________________________________________________________________________________
_____________________________________________________________________________________  








  
  
P pageLogin
  T tag[0:FORM ; 1:ERROR ; 2:SUCCESS]
  T stop[0]
  T face[0:fForm ; 1:fError ; 2:fSuccess]

  F fForm group
    PF bg        : image "login_bg.png"
    PF title     : text "Connexion"
    PF inputUser : input "Identifiant"
    PF inputPass : input "Mot de passe"

    P btnLogin M moduleButton
      --mouse-out    = F image "btn_out.png"
      --mouse-over   = F image "btn_over.png"
      --mouse-pushed = F image "btn_pushed.png"
      --click = () => {
        pageLogin.request.requestPhp();
      }

    P request M moduleRequestPHP
      --url        = "login.php"
      --params     =  () => [inputUser.value, inputPass.value]
      --sender     = this
      --on-success = (message) => {
        pageLogin.sendTag("SUCCESS");
      }
      --on-error   = (message) => {
        pageLogin.sendTag("ERROR");
      }

  F fError group
    PF bg     : image "login_bg.png"
    PF title  : text "Connexion"
    PF msgErr : text "Identifiant ou mot de passe incorrect."
    P btnRetry M moduleButton
      --mouse-out    = F image "btn_out.png"
      --mouse-over   = F image "btn_over.png"
      --mouse-pushed = F image "btn_pushed.png"
      --click = () => { pageLogin.sendTag("FORM"); }

  F fSuccess group
    PF bg    : image "login_bg.png"
    PF title : text "Connexion"
    PF msgOk : text "Bienvenue !"
    P btnHome M moduleButton
      --mouse-out    = F image "btn_out.png"
      --mouse-over   = F image "btn_over.png"
      --mouse-pushed = F image "btn_pushed.png"
      --click = () => { app.sendTag("HOME"); }
      
_____________________________________________________________________________________
_____________________________________________________________________________________      
      
      
      
      
P pageLogin
  T tag[0:FORM ; 1:ERROR ; 2:SUCCESS]
  T stop[0]
  T face[0:fForm ; 1:fError ; 2:fSuccess]

  F fForm group
    PF bg        : image "login_bg.png"
    PF title     : text "Connexion"
    PF inputUser : input "Identifiant"
    PF inputPass : input "Mot de passe"

    P msgLocal M modulePage
      --page-0 = F text "Veuillez entrer votre pseudo et votre code secret"
      --page-1 = F text "Erreur veuillez entre votre pseudo"
      --page-2 = F text "Erreur veuillez entre votre code secret"    
      --page-3 = F text "Identifiants en traitement"    

    P btnLogin M moduleButton
      --mouse-out    = F image "btn_out.png"
      --mouse-over   = F image "btn_over.png"
      --mouse-pushed = F image "btn_pushed.png"
      --click = () => {
        // ##emits _parent.msgLocal : PAGE_0, PAGE_1, PAGE_2, PAGE_3
        if validUser(_parent.msgLocal, PAGE_1, PAGE_2, PAGE_3) {
          pageLogin.login.requestPhp();
        }
      }

    P request M moduleRequestPHP
      --url        = "login.php"
      --params     =  () => [inputUser.value, inputPass.value]
      --sender     = this
      --on-success = (message) => {
        pageLogin.sendTag("SUCCESS");
      }
      --on-error   = (message) => {
        pageLogin.sendTag("ERROR");
      }

  F fError group
    PF bg     : image "login_bg.png"
    PF title  : text "Connexion"
    PF msgErr : text "Identifiant ou mot de passe incorrect."
    P btnRetry M moduleButton
      --mouse-out    = F image "btn_out.png"
      --mouse-over   = F image "btn_over.png"
      --mouse-pushed = F image "btn_pushed.png"
      --click = () => { pageLogin.sendTag("FORM"); }

  F fSuccess group
    PF bg    : image "login_bg.png"
    PF title : text "Connexion"
    PF msgOk : text "Bienvenue !"
    P btnHome M moduleButton
      --mouse-out    = F image "btn_out.png"
      --mouse-over   = F image "btn_over.png"
      --mouse-pushed = F image "btn_pushed.png"
      --click = () => { app.sendTag("HOME"); }      
      
      
      
      
_____________________________________________________________________________________
_____________________________________________________________________________________
Exemple d'usage de cadre paginé


P msgLocal M modulePage
  --page-0 = F text "Veuillez entrer votre pseudo et votre code secret"
  --page-1 = F text "Erreur veuillez entre votre pseudo"
  --page-2 = F text "Erreur veuillez entre votre code secret"    
  --page-3 = F text "Identifiants en traitement"    
  
--click = () => {
    // ##emits _parent.msgLocal : PAGE_0, PAGE_1, PAGE_2, PAGE_3
    if validUser(_parent.msgLocal, PAGE_1, PAGE_2, PAGE_3) {
        pageLogin.login.requestPhp();
    }
}
