# Optimization through modules

A recurring subtree can be **encapsulated** as a module. The module exposes a declared interface — its parameters — and hides its internal mechanics. It behaves exactly like an ordinary Piece in the tree.

---   

## The principle

**A repetitive native subtree:**

```
P isolation
  F f0 group
    P button
      T tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
      T stop[0]
      T face[0:fOut ; 1:fOver ; 2:fPushed]
      F fOut    image "btn_out.png"
      F fOver   image "btn_over.png"
      F fPushed image "btn_pushed.png"
```

**Becomes a module:**

```
M P moduleButton
  doc `
    ##role
        3-state button               // informational
    ##usage 
      P <pieceName> M moduleButton      // informational
      --click = <function>
      --mouseOut = <face>
      --mouseOver = <face>
      --mousePushed = <face>     
  `
  contract{
    timeline_isolated = true  // security
  } 
  params(
    F --mouseOut
    F --mouseOver
    F --mousePushed
  )
  modele (
    PF <pieceName> : group  // groupe isolation synchro
        P button
            T tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
            T stop[0]
            T face[0:fOut ; 1:fOver ; 2:fPushed]
            T click[0:--click]
            F fOut    = --mouseOut
            F fOver   = --mouseOver
            F fPushed = --mousePushed
  )
```

The internal mechanics — tags, stop, face track, timeline isolation — are invisible. The module already knows how to handle its three states.

Note that parameters are typed. Here, Faces are expected.

**Is instancied:**
```
P <pieceName> M moduleButton
    --click = ((x,y, sender)=>{...}
    --mouseOut = F ...
    --mouseOver = F ...
    --mousePushed = F ...
```


## Module declaration

A module declaration is a named Piece that encapsulates a reusable subtree behind a typed parameter interface.

**Note — Modules as first-class constructs**
Modules are treated as simply as functions or classes in a programming language.
They can be:

Declared - syntax: M P <module_name> - defined inline during page authoring within the document structure. These modules can then be stored in libraries and imported for reuse across projects.

A module library is a collection of named module declarations. Any module in scope can be instantiated with P <piece_name> M <module_name> without knowledge of its internal mechanics.


### Syntax

The module declaration is introduced by M (for Module)

```
M P <moduleName>
    doc    `<description>`           // informational — human-readable 
    contract{
        <rules>   // formal guarantees enforced by the engine
        returns {
            emits <emit_type><list returned>
        }
    }   
    params(
        <type> --<param-name>,
        ...
    )
    modele (
        <tispi-subtree using --param-name references>
    )
```
    
<description> ::= (<doc_subject> <explain>)*
<doc_subject> ::= "###role" | "###usage" |"###navigation" | "###behavior" | "###requires"
<emit_type> ::= "on success"? "on error"? "produces"? 



### Fields

| Field | Required | Role |
|---|---|---|
| `doc` | no | Human-readable description |
| `contract` | no | Formal guarantees — the engine enforces these at instantiation |
| `params` | yes | Typed input interface — defines what the caller must supply |
| `modele` | no | Internal template — the subtree the engine generates, with `--param-name` substitutions |

## Parameters

Parameters define the public interface of a module.
Each parameter is **typed**, and its type determines the nature of the expected value.

Types fall into three categories:

1. **Simple types**
2. **Indexed collections**
3. **Structural types (Piece / Face)**


### Parameter types

| Type | Description |
|---|---|
| `F` | Face — simple or group |
| `P` | Piece — complete subtree |
| `M` | Module - a complete subtree reduced to a single node |
| `bool` | Boolean value |
| `int` | Signed integer |
| `float` | Floating-point number |
| `string` | Character string |
| `color` | Color value |
| `func` | Callback function |

List non exhaustive

A parameter name ending in `__@frameNum__` declares an **indexed collection** — the caller supplies `--param_3_`, `--param_9_`, etc.

#### Example

Declaration:

```
params(
  bool    --enabled
  int     --count
  float   --ratio
  string  --label
  color   --tint
  func    --click
)
```

Instantiation:

```
P <pieceName> M moduleExample
  --enabled = true
  --count   = 3
  --ratio   = 0.75
  --label   = "Hello"
  --tint    = #FF8800
  --click   = (x,y) => { this.setPos(x,y); }
  --action  = () => { alert('Hello word'); }
```


### Indexed collections

A collection is a **repeatable** parameter, identified by an `_@index_` suffix.
The syntax requires the parameter name to end with `_@index_` in the declaration.

#### Declaration

```
params(
  F --page__@frameNum__
)
```

#### Instantiation

```
--page_3 = F ...
--page_9 = F ...
--page_12 = F ...
```

#### Rules

- Indexed collection indexes must be sorted in ascending order.
- Each index must be provided exactly once.
- The type of each entry must match the declared type.
- The module automatically deduces the cardinality and generates the associated internal structures (e.g. Tags, tracks, transitions).

---

### Structural types: `Piece` and `Face`

Parameters can be typed with the following structural types:

| Type | Description |
|------|-------------|
| `F` | Expects a Face (simple or group) |
| `P` | Expects a Piece (complete subtree) |

---

## Structural components of a `Piece`

Types of elements that can be declared within a `Piece`:

| Type | Description                                |
| ---- | ------------------------------------------ |
| `T`  | Declares a track                           |
| `C`  | Declares a constant initialization         |
| `F`  | Declares a Face (simple or group)          |
| `P`  | Declares a nested Piece (complete subtree) |

### Contract keys

| Key | Type | Description |
|---|---|---|
| `timeline_isolated` | bool | The module guarantees its internal timeline does not interfere with the parent |

### Instantiation syntax

```
P <instanceName> M <moduleName>
  --<param-name> = <value>
  ...
```

## Meta-language (modele only)

The `modele` block does not contain raw Tispi.
It uses a meta-language that is expanded into valid Tispi at instantiation.

This meta-language allows pattern expressions such as indexed expansion.

### Expansion syntax

`@name` défini un index pour la Piece

`@name:<pattern>` defines an expansion over indexed parameters.

- `@name` iterates over the set of indexes extracted from the indexed parameter used in the pattern (sample : `--page__@frameNum__`)
- The set is:
  - unique in Piece
  - sorted ascending

- The pattern is expanded by substituting `i` with each index

### Example

**instanciation:**

--page_3 = F type ...
--page_9 = F type ...
--page_12 = F type ...

**format:**

T tag[@index:PAGE_@index_]
T face[@index:fpage_@index_]
F fpage_@index_ = --page_@index_

**expands to:**

T tag[3:PAGE_3_ ; 9:PAGE_9_ ; 12:PAGE_12_]
T face[3:fpage_3_ ; 9:fpage_9_ ; 12:fpage_12_]
F fpage_3_ = --page_3_
F fpage_9_ = --page_9_
F fpage_12_ = --page_12_

### Important

- This syntax is **not valid Tispi**
- It must only appear inside `modele`
- The expanded result must always be valid Tispi

### Rules

- `<moduleName>` follows variable naming rules — letters, digits, underscore only
- `<instanceName>` must be unique among sibling Pieces in its group
- All `params` entries must be supplied at instantiation
- Indexed collection indexes must be in progressive order
- The --name notation designates a named variable. A variable declared in params is a caller-supplied parameter — its value is substituted at instantiation. Other --name variables may exist as engine-produced values, internal to the module

## Common modules

**Rollover:**

```
M P moduleRollover
  doc `
    ##role
      roll-over
      
    ##usage 
      P <pieceName> M moduleRollover
      --mouseOut = <face>
      --mouseOver = <face>
  `    
  contract {
    timeline_isolated = true
  } 
  params {
    F --mouseOut
    F --mouseOver
  }
  modele {
    PF <pieceName> : group
        P rollover
            T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
            T stop[0]
            T face[0:fOut ; 1:fOver]
            F fOut    = --mouseOut
            F fOver   = --mouseOver
  }
```

**Paginated frame — variable parameter:**

We discover the template syntax for defining an expected array.

`@<var>` denotes an index variable.

- `<var>` is a user-defined name (e.g. `page`, `item`, `state`)
- At instantiation, the value of @<var> is defined by the index of the variable.

- Example:
   at declaration =>
      tags [@index: PAGE_@index_]
      params(
        F --page_@index_
      )
   at instantiation =>
      --param-9 = Type value 
      => replaces @index => tags [9: PAGE_9_]
- It is substituted by each index value during expansion

- Example in the Page module:

```
M P modulePages
  doc `
    ##role
        cadre paginé
  
    ##usage
        P <pieceName> M modulePages
            --page_<num_frame>_ = <face>
  
    ##navigation
        <piece>.sendTag(PAGE_<index>_);
  `
  contract {
    timeline_isolated = true // security
  }
  params {
    F --page_@index_
  }
  modele { // Notez la Syntaxe de tableau de valeur
    PF <pieceName> : group
        P pages
            T tag[@index:PAGE_@index_] // @index is unic in Piece
            T stop[0]
            T face[@index:fpage_@index_]
            F fpage_@index_    = --page_@index_    
  }
```

The module deduces the number of pages by counting the `--page_0_`, `--page_3_`, `--page_9_`… entries provided at usage. It automatically generates Tags `PAGE_0_`, `PAGE_3_`, `PAGE_9_`…

```
P myPages M modulePages
  --page_0_ = F group
    PF bg    : image "page0_bg.png"
    PF label : text "Page 0"
  --page_3_ = F group
    PF bg    : image "page1_bg.png"
    PF label : text "Page 1"
  --page_9_ = F group
    PF bg    : image "page2_bg.png"
    PF label : text "Page 2"
```

---

## Modules are Pieces

A module inserts into the tree exactly like an ordinary Piece. It respects the P/F alternation — it introduces no grammatical exception.

```
P myPages M modulePages
  --page_2_ = F group
    PF bg    : image "page2_bg.png"
    PF label : text "Page 2"
    P myButton M moduleButton
      --mouseOut    = F image "btn_out.png"
      --mouseOver   = F image "btn_over.png"
      --mousePushed = F image "btn_pushed.png"
```

`moduleButton` is directly a Piece inside `--page_2_`'s group. No wrapper Face, no intermediate group — it nests naturally.

---

## What this step provides

| Before the module | After the module |
|---|---|
| Mechanics rebuilt at every usage | Encapsulated once, reused without friction |
| Internal structure visible | Interface alone exposed |
| Possible omission errors | Behavior guaranteed by the module |

The complexity does not disappear — it moves inside the module. The usage tree remains readable, minimal, composable. This is the **@Lego** principle: autonomous bricks with a declared interface, that fit together without knowing each other.

---

## Composition by stacking

Each module is an autonomous brick, with a declared interface, that slots into the tree without friction. `moduleButton` inserts into `modulePages` like one Lego brick into another — without knowing its context, without modifying the grammar.

```
P OtherPages M modulePages
  --page_0_ = F group
    PF bg    : image "page0_bg.png"
    PF label : text "Page 0"
  --page_1_ = F group
    PF bg    : image "page1_bg.png"
    PF label : text "Page 1"
  --page_2_ = F group
    PF bg    : image "page2_bg.png"
    PF label : text "Page 2"
    P otherButton M moduleButton
      --mouseOut    = F image "btn_out.png"
      --mouseOver   = F image "btn_over.png"
      --mousePushed = F image "btn_pushed.png"
```

---



# Decoration components — draft

## Les type composites :
x ::= float
y ::= float
l ::= float
h ::= float

fontname ::=string
tag ::= pathPiece string
color ::= #hex
size ::= number
style ::= number
 
bounds ::= "*bounds*"? // pour test
color ::= "red" | "green" | "blue" | vide // pour test 
background ::= color?
textStyle ::= "*style*"? // pour test
pathPiece ::= (pathHeader "." (pieceName)*)? '.' string
pathHeader ::= "_this" | "_parent" | "_brother"
pieceName ::= string

## Faces : méta-déclaration (DSL)

Ici nous déclarons les Faces
Nouvelle règle Tispi.

Syntaxe commençant par D comme déclaration
D F type 
    params{
      <type> <param_naame>
      ...
    }
    syntaxe{
      F <name> <family> <attributes>
    }   

### text
  D F name text
    params {
      bounds area
      color bgColor
      textStyle textStyle
      string text
    }
    syntaxe {
      F <name> text (bounds* red *style*)? "texte dans la zone"
      Examples:
      - F name text *bounds* red *style* "texte dans la zone"
      - F name text "texte dans la zone"
    }

## Un modèle

Plus compliqué à traiter en module qu'à l'utiliser comme modèle
Prenons ce modèle et ajoutons les faces et les propriété nécessaires.
 
### Button simple
  F <pieceName> : group  // isolation synchro
    P fond
      T tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
      T stop[0]
      T click[0:<clickAction>]     
      T --<cssProperty>[
          0:<value>,[<duration>:<acceleration>,<effect>], 
          1:<value>,[<duration>:<acceleration>,<effect>], 
          2:<value>,[<duration>:<acceleration>,<effect>], 
          ]
      ...    
      F rectangle --<cssProperty>    
    P Text 
      T --<cssProperty>[
          0:<value>,[<duration>:<acceleration>,<effect>], 
          1:<value>,[<duration>:<acceleration>,<effect>], 
          2:<value>,[<duration>:<acceleration>,<effect>], 
          ]
      ...    
      F text --<cssProperty>...
  }

Exemple :
  F f0 group  // isolation synchro
    P fond
      tr [12, easeOut, face] 
      T tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
      T stop[0]
      T click[0:()=>{alert("Hello word");}]        
      T --background[0:blue; 1:cyan; 2:green]
      F f0 rectangle  --background 
    P Text
      T --textColor[0:yellow; 1:white; 2:black]
      T --style[0:normal; 1:bold; 2:italic]
      T --text[0:"goto"; 1:"in"; 2:"space"]
      F f0 text --textColor --style --text
  }



## Les modules 

M P moduleButton
  doc `
    ##role 
      3-state button               
        
    ##instanciation
      P <pieceName> M moduleButton
        func --click = <function>
        tag --sendTag = <tag>
        F --mouseOut = <face>
        F --mouseOver = <face>
        F --mousePushed = <face>     
  `
  contract {
    timeline_isolated = true // security
  } 
  params {
    func --click
    tag --sendTag
    F --mouseOut
    F --mouseOver
    F --mousePushed
  }
  modele {
    PF <pieceName> : group  // isolation synchro
        P button
            T tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED; 3:MOUSE_CLICK]
            T stop[0]
            T face[0:fOut ; 1:fOver ; 2:fPushed]
            T click[3:--click]
            T sendTag[3:--sendTag]
            F fOut    = --mouseOut
            F fOver   = --mouseOver
            F fPushed = --mousePushed
  }
 
_____________________________________________________________________________________
_____________________________________________________________________________________

M P moduleRollover
  doc `
    ##role
      roll-over
      
    ##instanciation
      P <pieceName> M moduleRollover
      --mouseOut = <face>
      --mouseOver = <face>
  `    
  contract {
    timeline_isolated = true
  } 
  params {
    F --mouseOut
    F --mouseOver
  }
  modele {
    PF <pieceName> : group
        P rollover
            T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
            T stop[0]
            T face[0:fOut ; 1:fOver]
            F fOut    = --mouseOut
            F fOver   = --mouseOver
  }

_____________________________________________________________________________________
_____________________________________________________________________________________

M P modulePages
  doc `
    ##role
        cadre paginé
  
    ##instanciation
        P <pieceName> M modulePages
            F --fpage_<frameNum>_ = <face>  // <face> sans 'F' au début

        F --fpage_<frameNum>_ parameter generates a Face named fpage_<frameNum>_    
        Ex :
          Déclaration
            P album M modulePages
              F --fpage_0_ = text "message 0"
              F --fpage_1_ = text "message 1"
              F --fpage_2_ = text "message 2"
              
    ##parameter contract
        Pour accéder à une page
            <Piece>.fpage_<frameNum>_ 
            exemple : _this.album.pages.fpage_12_
            exemple : _this.album.pages.fpage_{--numPage}_
                
        Navigation
            <piece>.pages.sendTag(PAGE_<frameNum>_);
  `
  contract {
    timeline_isolated = true
  } 
  params {
    F --fpage_{@frameNum}_
  }
  modele { // Notez la Syntaxe de tableau de valeur
    PF <pieceName> : group
        P pages 
            A isFaceArray 
            T tag[@frameNum:PAGE_{@frameNum}_]
            T stop[0]
            T face[@frameNum:fpage_{@frameNum}_]
            F fpage_{@frameNum}_ = --fpage_{@frameNum}_
    }

_____________________________________________________________________________________
_____________________________________________________________________________________

M P moduleButtonListLine
    doc `
        ##role 
            liste de bouton affichés en en ligne                
        ##instanciation 
            P <pieceName> M moduleButtonListLine
                C --align = <T pos>
                func --onclick_{@posIndex}_ = <func(x, y, sender)>
                F --mouseOut_{@posIndex}_ = <face> // <face> sans 'F' au début
                F --mouseOver_{@posIndex}_ = <face> // <face> sans 'F' au début
                F --mousePushed_{@posIndex}_ = <face> // <face> sans 'F' au début
            Exemple :
                PF buttons M moduleButtonListLine
                  C align = align[0:{@posIndex * 50} 0]
                  P bt_0_
                    C --onclick_0_ =()=>alert("button 0");
                    F --mouseOut_0_ = text "out 0"
                    F --mouseOver_0_ = text "over 0"
                    F --mousePushed_0_ = text "pushed 0"
                  P bt_1_
                    C --onclick_1_ =()=>alert("button 0");
                    F --mouseOut_1_ = text "out 0"
                        // note : sans les états suivant, "out 0" est naturellement répété sur les états suivant de MOUSE_OUT => MOUSE_OVER, MOUSE_PUSHED
                    
        ##behavior
            Au clic sur un bouton (onclick), exécute l'action
    `
    params {
        P --pieceBt_{@posIndex}_
        F --mouseOut_{@posIndex}_
        F --mouseOver_{@posIndex}_
        F --mousePushed_{@posIndex}_
        func --onclick_{@posIndex}_
        pos --align
    }
    modele {
        PF <indexTab> : group 
            A isPieceArray 
            C align = --align
            P name_{@posIndex}_ = --pieceBt_{@posIndex}_ 
                T tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
                T stop[0]
                T face[0:fOut_{@posIndex}_ ; 1:fOver_{@posIndex}_ ; 2:fPushed_{@posIndex}_ ] 
                C onclick_{@posIndex}_ = --onclick_{@posIndex}_
                F fOut_{@posIndex}_    = --mouseOut_{@posIndex}_
                F fOver_{@posIndex}_   = --mouseOver_{@posIndex}_
                F fPushed_{@posIndex}_ = --mousePushed_{@posIndex}_      
    }  

§extends Tispi rules
- onclick est un mot réservé Tispi - si présent => remplace T click[] 

- Principe de substitution
  Dans un modele, toute valeur peut être remplacée par un paramètre :
  F <name> = --<param>    // substitution de Face
  P <name> = --<param>    // substitution de Piece
  C <name> = --<param>    // substitution de constante
  T <name> = --<param>    // substitution de piste

  Le mécanisme est identique quel que soit le type.
  `= --param` signifie : remplacer ce nœud par la valeur fournie à l'instanciation.

  Pas d'exception — si une substitution ne fonctionne pas sur un type,
  c'est une règle incomplète ou un concept manquant.    

---

M P moduleIndexedPages
  doc `
    ##role 
      Pages dans un cadre indéxé               
        
    ##instanciation 
      P <pieceName> M moduleIndexedPages
      F --imageIndex_<posIndex>_ = <face> // <face> sans 'F' au début
      F --imageOver_<posIndex>_ = <face> // <face> sans 'F' au début
      F --imagePushed_<posIndex>_ = <face> // <face> sans 'F' au début
      F --doc_<posIndex>_ = <face> // <face> sans 'F' au début

    ##parameter contract
      navigation :
        <piece>.documents.sendTag(PAGE_<posIndex>_);

    ##behavior
      Au clic sur une vignette (MOUSE_CLICK),
      envoie PAGE_<posIndex>_ au parent → affiche le document correspondant.
  `
  contract {
    timeline_isolated = true // security
  } 
  params {
    F --imageIndex_{@posIndex}_
    F --imageOver_{@posIndex}_
    F --imagePushed_{@posIndex}_
    F --doc_{@posIndex}_
  }
  modele {
    PF <pieceName>: group
        PF <indexTab> : group 
          A isPieceArray 
            pos=pos[0:{@posIndex * 50} 0]
        
          M P moduleIcon   // Plusieurs Pieces affichées
            doc `
                ##role 
                3-state button               
                    
                ##usage 
                P <pieceName> M moduleIcon
                  C --sendTag = <tag>
                  F --mouseOut = <face>  // <face> sans 'F' au début
                  F --mouseOver = <face> // <face> sans 'F' au début
                  F --mousePushed = <face>   // <face> sans 'F' au début   
            `
            contract {
                timeline_isolated = true // security
            } 
            params {
                tag --sendTag
                F --mouseOut
                F --mouseOver
                F --mousePushed
            }
            modele {
                PF <pieceName> : group  // isolation synchro
                    P button
                        T tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED; 3:MOUSE_CLICK]
                        T stop[0]
                        T face[0:fOut ; 1:fOver ; 2:fPushed; 3:fOver ] // 3: maintien hover pendant click
                        T sendTag[3:--sendTag]
                        F fOut    = --mouseOut
                        F fOver   = --mouseOver
                        F fPushed = --mousePushed
            }
          P index_{@posIndex}_ M moduleIcon
            C --sendTag = _parent._parent.documents PAGE_{@posIndex}_
            F --mouseOut  = --imageIndex_{@posIndex}_
            F --mouseOver  = --imageOver_{@posIndex}_
            F --mousePushed = --imagePushed_{@posIndex}_

        P documents M modulePages
          F --fpage_{@posIndex}_ = --doc_{@posIndex}_
  }   
  
_____________________________________________________________________________________
_____________________________________________________________________________________

Rappel : 
- une face unique n'a pas besoin de "piste face"
- un valeur reste présente jusqu'à la key suivante. Même si elle peut se combiner avec la valeur de la keys suivante.
  => donc une face restera active jusqu'à la key suivant ou jusqu'à la fin
  => donc une face unique est toujours active.


  
Nouveauté :
- les pistes de variables
  leur nom est précédé de "--" pour indiquer qu'il sagit de variable. Ex : --text[...] 
  elle indique 'évolutionde la valeur d'une variable dans une piste de la barre de temps
  Dans l'exemple ci-dessous, les texte change à chaque temps dans : T --text[...]  
- transition au niveau de la Piece, et au niveau de la key
```
    PF messIdentification : group
        P pages
            tr : [0.5s, easeOut, fade]
            T tag[0:MESSAGE_IDLE ; 1:MESSAGE_OK ; 2:MESSAGE_ERROR_0; 3:MESSAGE_ERROR_1]
            T stop[0]
            T sendTag[1:_parent[PAGE_2].foo[STATE_3]]
            T --textContent[0:"en attente"; 1:"Correct, continuons"; 2:"Erreur entrez le pseudo"; 3:"Erreur entrez le code-secret"]
            T --color[0:black, 1:green, 2:red, [0.5s, easeOut, explode]] // Notez que red se propage jusqu-à la frame numéro 3

            F f0 text [100, 200, 400, 30] white ["Arial", 12, B, --color ] --textContent
```

_____________________________________________________________________________________
_____________________________________________________________________________________


M P moduleRequestPHP
  doc`
    ##role
      Requête PHP générique avec états et isolation temporelle
      
    ##instanciation 
      P <pieceName> M moduleRequestPHP
        --url = "my_php.php"
        --params = --phpParams
        --sender = _parent.form
        --on-success = "functionOk"
        --on-error = "functionError"

    ##navigation
      <pieceRequest>.requestPhp(params);
        
    ##behavior
      requestPhp() déplace automatiquement le playhead :
          => REQUEST_PENDING (requête en cours)
          => REQUEST_OK      (succès)
          => REQUEST_ERROR   (erreur)
    
    ##requires
      Tispi.phpRequest(--url, --params)
  `
  
  contract {
    timeline_isolated = true
    returns {
      emits on success: sender.receivePhp(--on-success, --message) // cf. --message received with produces
      emits on error:   sender.receivePhp(--on-error, --message)
      produces: --message ( fill by echo of PHP)
    }
  }
  params {
    string --url
    array --params
    P --sender
    func --on-success
    func --on-error
  }   
  
  modele {
    P <pieceName> // isolation synchronique
      C --requestPhp = ()=>{_this.request.sendTag(REQUEST_IDLE)}          
      F f0 group 
        P request
          T tag[0:REQUEST_WAIT; 1:REQUEST_IDLE; 2:REQUEST_PENDING ; 3:REQUEST_OK ; 4:REQUEST_ERROR]
          T stop[0]
          T face[2:fPending ; 3:fOk ; 4:fError]
          T sendTag[
            3:--sender --on-success --message, _this REQUEST_WAIT;
            4:--sender --on-error --message, _this REQUEST_WAIT
          ]
          T action[
            1: Tispi.io.phpRequest(_this, --url, --params) ;
          ]
          
          F fPending text "Requête en cours…"
          F fOk text ""
          F fError text ""
  }

# L'importance structurelle de la piste sendTag.

sendTag est la représentation canonique des transitions d’une machine à états dans Tispi, permettant une évolution entièrement déterministe et statiquement analysable.

---

## Reformulation correcte de `T sendTag`

### Principe

> **Une valeur de `sendTag` est une suite de tags à envoyer.**

Pas de distinction structurelle :

* ❌ pas “émission externe vs action locale”
* ✔ uniquement une **liste d’envois de tags**

---

## 1. Example walkthrough

```tispi
T sendTag[
  3:--sender --on-success --message, _this REQUEST_WAIT;
  4:--sender --on-error --message, _this REQUEST_WAIT;
]
```

---

## 2. Décomposition correcte

Chaque keyframe contient :

```text
frame : sendTag, sendTag, ...
```

---

### 2.1 Un `sendTag`

Forme générale :

```text
<cible> <tag> [paramètres...]
```

---

### 2.2 Application to this case

#### Première instruction

```tispi
--sender --on-success --message
```

→ envoi d’un tag :

* cible : `--sender`
* tag : `--on-success`
* paramètre : `--message`

---

#### Deuxième instruction

```tispi
_this REQUEST_WAIT
```

→ envoi d’un tag :

* cible : `_this`
* tag : `REQUEST_WAIT`
* pas de paramètre

---

## 3. Syntaxe simplifiée

```ebnf
sendTag ::= send (',' send)* ;

send ::= target tag (value)*
```

---

## 4. Nature du mécanisme

`sendTag` est donc :

> **une piste déclarative d’envoi de tags à des cibles**

Chaque entrée :

* ne décrit pas une action
* ne décrit pas une logique
* décrit uniquement **des envois**

---

## 5. Propriété importante

Contrairement à `action` :

* `action` → exécute du code
* `sendTag` → **déclare des transitions / notifications**

---

## 6. Conséquence conceptuelle

This formulation enforces a purer reading of the model:

> Le système ne fait pas “des actions”
> Il **propage des états (tags)**

---

## 7. Résumé final

✔ Une keyframe de `sendTag` = liste de tags à envoyer
✔ Chaque élément = `cible + tag + paramètres éventuels`
✔ Pas de notion de “bloc”
✔ Pas de hiérarchie interne

---

## Formulation propre

> **`T sendTag` est une piste qui décrit, pour chaque frame, une liste de tags à envoyer à des cibles données, éventuellement accompagnés de paramètres.**

## Classic Tispi pitfalls

- Forgetting that modules are Pieces

- Wrong parameter type in a module
The Tispi engine checks whether a parameter has the wrong type in a module.

# extends Tispi rules
- Têtes de path réservées :
    _this    : désigne la Piece courante
    _parent  : désigne la Piece parent
    _brother : désigne l’espace des Pieces sœurs du groupe courant
    
    Syntaxe :
    <path> ::= _this
            | _parent
            | _brother.<pieceName>
            | <path>.<pieceName>
            | <path>.<propertyName>
    
    Règles :
    - Un path contextuel doit commencer par une tête de path réservée.
    - `_brother` doit toujours être suivi du nom d’une Piece sœur.
    - Les têtes de path réservées ne peuvent pas être utilisées comme noms de Piece.
    - Rappel : A referenced sibling Piece must exist and be uniquely identified within its parent Face group.
    
- @frameNum : désigne l'index courant de la Piece 
    Meta variable available only in module definitions
    - @<path>.index
      Référence à l'index d'une autre Piece.
      Utilisable dans tout modele imbriqué dans un module indexé.
      Exemple : 
        {@_parent.index} = référence à l'index de la Pièce parent
        {@pieceName.index} = référence à une pièce nommée pieceName

- Convention de nommage :
    | Élément | Forme | Exemple |
    |---|---|---|
    | Variable auteur | `--camelCase` | `--numPage`, `--mouseOut` |
    | Variable système | `@camelCase` | `@frameNum`, `@parentIndex` |
    | Nœud indexé | `name_{@frameNum}_` | `fpage_{@frameNum}_` → `fpage_12_` |
    | Tag système | SCREAMING_SNAKE        | MOUSE_OUT, MOUSE_OVER   |
    | Tag indexé  | NAME_{@frameNum}_      | PAGE_{@frameNum}_ → PAGE_12_ |

- {} : requis pour toute variable insérée dans un nom de nœud,
  un littéral, ou une expression calculée.
  
  | Contexte | Notation | Exemple |
  |---|---|---|
  | Expression calculée | `{}` | `{@frameNum * 50}` |
  | Variable dans un nom | `{}` | `fpage_{@frameNum}_` |
  | Variable auteur dans un nom | `{}` | `fpage_{--numPage}_` |
  | Référence simple hors nom | sans `{}` | `--var`, `@frameNum` |  

- A isFaceArray : attribut de Piece — indique que la Piece 
  contient une collection de Faces indexées expansibles.
  Le moteur génère une instance de Face par @frameNum trouvé 
  dans les params de type F --name_{@frameNum}_. 

- A isPieceArray : attribut de Face — indique que la Face
  contient une collection de Pieces expansibles.
  Non structurel — optimisation de description uniquement.
  Propriétés disponibles :
    pos = pos[0:{@frameNum * 50} 0]  // position calculée par index 

- tag : type "tag" pour une variable
  tag ::= pathPiece string
  pathPiece ::= (pathHeader "." (pieceName)*)? '.' string
  pathHeader ::= "_this" | "_parent" | "_brother"
  pieceName ::= string

- @posIndex : meta-variable système disponible dans les définitions 
  de modules. Désigne le numéro de frame courant dans le contexte 
  d'expansion indexée.

- Un module déclaré dans un modele est local à ce modele.
  Il n'est pas accessible depuis l'extérieur du module parent.
  Sa portée est limitée à la branche dans laquelle il est déclaré. 
