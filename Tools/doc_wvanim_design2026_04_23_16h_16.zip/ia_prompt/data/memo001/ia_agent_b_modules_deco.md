# Optimization through modules

a recurring subtree can be **encapsulated** as a module. The module exposes a declared interface — its parameters — and hides its internal mechanics. It behaves exactly like an ordinary Piece in the tree.

---   

## The principle

**a repetitive native subtree:**

```
p Isolation
  f F0 group
    p Button
      t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
      t stop[0]
      t face[0:FOut ; 1:FOver ; 2:FPushed]
      f FOut    image "btn_out.png"
      f FOver   image "btn_over.png"
      f FPushed image "btn_pushed.png"
```

**Becomes a module:**

```
m p ModuleButton
  doc `
    ##role
        3-state button               // informational
    ##usage 
      p <PieceName> m ModuleButton      // informational
      --click = <function>
      --mouseOut = <face>
      --mouseOver = <face>
      --mousePushed = <face>     
  `
  contract{
    timeline_isolated = true  // security
  } 
  params(
    f --mouseOut
    f --mouseOver
    f --mousePushed
  )
  modele (
    pf <PieceName> : group  // groupe isolation synchro
        p Button
            t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
            t stop[0]
            t face[0:FOut ; 1:FOver ; 2:FPushed]
            t click[0:--click]
            f FOut    = --mouseOut
            f FOver   = --mouseOver
            f FPushed = --mousePushed
  )
```

The internal mechanics — tags, stop, face track, timeline isolation — are invisible. The module already knows how to handle its three states.

Note that parameters are typed. Here, Faces are expected.

**Is instancied:**
```
p <PieceName> m ModuleButton
    --click = ((x,y, sender)=>{...}
    --mouseOut = f ...
    --mouseOver = f ...
    --mousePushed = f ...
```


## Module declaration

a module declaration is a named Piece that encapsulates a reusable subtree behind a typed parameter interface.

**Note — Modules as first-class constructs**
Modules are treated as simply as functions or classes in a programming language.
They can be:

Declared - syntax: m p <ModuleName> - defined inline during page authoring within the document structure. These modules can then be stored in libraries and imported for reuse across projects.

a module library is a collection of named module declarations. Any module in scope can be instantiated with p <PieceName> m <ModuleName> without knowledge of its internal mechanics.


### Syntax

The module declaration is introduced by m (for Module)

```
m p <ModuleName>
    doc    `<description>`           // informational — human-readable 
    contract{
        <rules>   // formal guarantees enforced by the engine
        returns {
            emits <emit_type><list returned>
        }
    }   
    params(
        <type> --<param-name>,
        ...
    )
    modele (
        <tispi-subtree using --param-name references>
    )
```
    
<description> ::= (<doc_subject> <explain>)*
<doc_subject> ::= "###role" | "###usage" |"###navigation" | "###behavior" | "###requires"
<emit_type> ::= "on success"? "on error"? "produces"? 



### Fields

| Field | Required | Role |
|---|---|---|
| `doc` | no | Human-readable description |
| `contract` | no | Formal guarantees — the engine enforces these at instantiation |
| `params` | yes | Typed input interface — defines what the caller must supply |
| `modele` | no | Internal template — the subtree the engine generates, with `--param-name` substitutions |

## Parameters

Parameters define the public interface of a module.
Each parameter is **typed**, and its type determines the nature of the expected value.

Types fall into three categories:

1. **Simple types**
2. **Indexed collections**
3. **Structural types (Piece / Face)**


### Parameter types

| Type | Description |
|---|---|
| `f` | Face — simple or group |
| `p` | Piece — complete subtree |
| `m` | Module - a complete subtree reduced to a single node |
| `bool` | Boolean value |
| `int` | Signed integer |
| `float` | Floating-point number |
| `string` | Character string |
| `color` | Color value |
| `func` | Callback function |

List non exhaustive

a parameter name ending in `__@frameNum__` declares an **indexed collection** — the caller supplies `--param_3_`, `--param_9_`, etc.

#### Example

Declaration:

```
params(
  bool    --enabled
  int     --count
  float   --ratio
  string  --label
  color   --tint
  func    --click
)
```

Instantiation:

```
p <PieceName> m ModuleExample
  --enabled = true
  --count   = 3
  --ratio   = 0.75
  --label   = "Hello"
  --tint    = #FF8800
  --click   = (x,y) => { this.setPos(x,y); }
  --action  = () => { alert('Hello word'); }
```


### Indexed collections

a collection is a **repeatable** parameter, identified by an `_@index_` suffix.
The syntax requires the parameter name to end with `_@index_` in the declaration.

#### Declaration

```
params(
  f --page__@frameNum__
)
```

#### Instantiation

```
--page_3 = f ...
--page_9 = f ...
--page_12 = f ...
```

#### Rules

- Indexed collection indexes must be sorted in ascending order.
- Each index must be provided exactly once.
- The type of each entry must match the declared type.
- The module automatically deduces the cardinality and generates the associated internal structures (e.g. Tags, tracks, transitions).

---

### Structural types: `Piece` and `Face`

Parameters can be typed with the following structural types:

| Type | Description |
|------|-------------|
| `f` | Expects a Face (simple or group) |
| `p` | Expects a Piece (complete subtree) |

---

## Structural components of a `Piece`

Types of elements that can be declared within a `Piece`:

| Type | Description                                |
| ---- | ------------------------------------------ |
| `t`  | Declares a track                           |
| `c`  | Declares a constant initialization         |
| `f`  | Declares a Face (simple or group)          |
| `p`  | Declares a nested Piece (complete subtree) |

### Contract keys

| Key | Type | Description |
|---|---|---|
| `timeline_isolated` | bool | The module guarantees its internal timeline does not interfere with the parent |

### Instantiation syntax

```
p <InstanceName> m <ModuleName>
  --<param-name> = <value>
  ...
```

## Meta-language (modele only)

The `modele` block does not contain raw Tispi.
It uses a meta-language that is expanded into valid Tispi at instantiation.

This meta-language allows pattern expressions such as indexed expansion.

### Expansion syntax

`@name` défini un index pour la Piece

`@name:<pattern>` defines an expansion over indexed parameters.

- `@name` iterates over the set of indexes extracted from the indexed parameter used in the pattern (sample : `--page__@frameNum__`)
- The set is:
  - unique in Piece
  - sorted ascending

- The pattern is expanded by substituting `i` with each index

### Example

**instanciation:**

--page_3 = f type ...
--page_9 = f type ...
--page_12 = f type ...

**format:**

t tag[@index:PAGE_@index_]
t face[@index:Fpage_@index_]
f Fpage_@index_ = --page_@index_

**expands to:**

t tag[3:PAGE_3_ ; 9:PAGE_9_ ; 12:PAGE_12_]
t face[3:Fpage_3_ ; 9:Fpage_9_ ; 12:Fpage_12_]
f Fpage_3_ = --page_3_
f Fpage_9_ = --page_9_
f Fpage_12_ = --page_12_

### Important

- This syntax is **not valid Tispi**
- It must only appear inside `modele`
- The expanded result must always be valid Tispi

### Rules

- `<moduleName>` follows variable naming rules — letters, digits, underscore only
- `<instanceName>` must be unique among sibling Pieces in its group
- All `params` entries must be supplied at instantiation
- Indexed collection indexes must be in progressive order
- The --name notation designates a named variable. a variable declared in params is a caller-supplied parameter — its value is substituted at instantiation. Other --name variables may exist as engine-produced values, internal to the module

## Common modules

**Rollover:**

```
m p ModuleRollover
  doc `
    ##role
      roll-over
      
    ##usage 
      p <PieceName> m ModuleRollover
      --mouseOut = <face>
      --mouseOver = <face>
  `    
  contract {
    timeline_isolated = true
  } 
  params {
    f --mouseOut
    f --mouseOver
  }
  modele {
    pf <PieceName> : group
        p Rollover
            t tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
            t stop[0]
            t face[0:FOut ; 1:FOver]
            f FOut    = --mouseOut
            f FOver   = --mouseOver
  }
```

**Paginated frame — variable parameter:**

We discover the template syntax for defining an expected array.

`@<var>` denotes an index variable.

- `<var>` is a user-defined name (e.g. `page`, `item`, `state`)
- At instantiation, the value of @<var> is defined by the index of the variable.

- Example:
   at declaration =>
      tags [@index: PAGE_@index_]
      params(
        f --page_@index_
      )
   at instantiation =>
      --param-9 = Type value 
      => replaces @index => tags [9: PAGE_9_]
- It is substituted by each index value during expansion

- Example in the Page module:

```
m p modulePages
  doc `
    ##role
        cadre paginé
  
    ##usage
        p <PieceName> m ModulePages
            --page_<num_frame>_ = <face>
  
    ##navigation
        <piece>.sendTag(PAGE_<index>_);
  `
  contract {
    timeline_isolated = true // security
  }
  params {
    f --page_@index_
  }
  modele {
    pf <PieceName> : group
        p Pages
            t tag[@index:PAGE_@index_] // @index is unic in Piece
            t stop[0]
            t face[@index:Fpage_@index_]
            f Fpage_@index_    = --page_@index_    
  }
```

The module deduces the number of pages by counting the `--page_0_`, `--page_3_`, `--page_9_`… entries provided at usage. It automatically generates Tags `PAGE_0_`, `PAGE_3_`, `PAGE_9_`…

```
p MyPages m ModulePages
  --page_0_ = f group
    pf Bg    : image "page0_bg.png"
    pf Label : text "Page 0"
  --page_3_ = f group
    pf Bg    : image "page1_bg.png"
    pf Label : text "Page 1"
  --page_9_ = f group
    pf Bg    : image "page2_bg.png"
    pf Label : text "Page 2"
```

---

## Modules are Pieces

a module inserts into the tree exactly like an ordinary Piece. It respects the p/f alternation — it introduces no grammatical exception.

```
p MyPages m ModulePages
  --page_2_ = f group
    pf Bg    : image "page2_bg.png"
    pf Label : text "Page 2"
    p MyButton m ModuleButton
      --mouseOut    = f image "btn_out.png"
      --mouseOver   = f image "btn_over.png"
      --mousePushed = f image "btn_pushed.png"
```

`moduleButton` is directly a Piece inside `--page_2_`'s group. No wrapper Face, no intermediate group — it nests naturally.

---

## What this step provides

| Before the module | After the module |
|---|---|
| Mechanics rebuilt at every usage | Encapsulated once, reused without friction |
| Internal structure visible | Interface alone exposed |
| Possible omission errors | Behavior guaranteed by the module |

The complexity does not disappear — it moves inside the module. The usage tree remains readable, minimal, composable. This is the **@Lego** principle: autonomous bricks with a declared interface, that fit together without knowing each other.

---

## Composition by stacking

Each module is an autonomous brick, with a declared interface, that slots into the tree without friction. `moduleButton` inserts into `modulePages` like one Lego brick into another — without knowing its context, without modifying the grammar.

```
p OtherPages m ModulePages
  --page_0_ = f group
    pf Bg    : image "page0_bg.png"
    pf Label : text "Page 0"
  --page_1_ = f group
    pf Bg    : image "page1_bg.png"
    pf Label : text "Page 1"
  --page_2_ = f group
    pf Bg    : image "page2_bg.png"
    pf Label : text "Page 2"
    p OtherButton m ModuleButton
      --mouseOut    = f image "btn_out.png"
      --mouseOver   = f image "btn_over.png"
      --mousePushed = f image "btn_pushed.png"
```

---



# Decoration components — draft

## Les type composites :
x ::= float
y ::= float
l ::= float
h ::= float

fontname ::=string
tag ::= pathPiece string
color ::= #hex
size ::= number
style ::= number
 
bounds ::= "*bounds*"? // pour test
color ::= "red" | "green" | "blue" | vide // pour test 
background ::= color?
textStyle ::= "*style*"? // pour test
pathPiece ::= (pathHeader "." (pieceName)*)? '.' string
pathHeader ::= "_this" | "_parent" | "_brother"
pieceName ::= string

## Faces : méta-déclaration (DSL)

Ici nous déclarons les Faces
Nouvelle règle Tispi.

Syntaxe commençant par d comme déclaration
d f type 
    params{
      <type> <param_naame>
      ...
    }
    syntaxe{
      f <name> <family> <attributes>
    }   

### text
  d f name text
    params {
      bounds area
      color bgColor
      textStyle textStyle
      string text
    }
    syntaxe {
      f <name> text (bounds* red *style*)? "texte dans la zone"
      Examples:
      - f Name text *bounds* red *style* "texte dans la zone"
      - f Name text "texte dans la zone"
    }

## Un modèle

Plus compliqué à traiter en module qu'à l'utiliser comme modèle
Prenons ce modèle et ajoutons les faces et les propriété nécessaires.
 
### Button simple
  f <PieceName> : group  // isolation synchro
    p Fond
      t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
      t stop[0]
      t click[0:<clickAction>]     
      t --<cssProperty>[
          0:<value>,[<duration>:<acceleration>,<effect>], 
          1:<value>,[<duration>:<acceleration>,<effect>], 
          2:<value>,[<duration>:<acceleration>,<effect>], 
          ]
      ...    
      f Rectangle --<cssProperty>    
    p Text 
      t --<cssProperty>[
          0:<value>,[<duration>:<acceleration>,<effect>], 
          1:<value>,[<duration>:<acceleration>,<effect>], 
          2:<value>,[<duration>:<acceleration>,<effect>], 
          ]
      ...    
      f Text --<cssProperty>...
  }

Exemple :
  f F0 group  // isolation synchro
    p Fond
      tr [12, easeOut, face] 
      t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
      t stop[0]
      t click[0:()=>{alert("Hello word");}]        
      t --background[0:blue; 1:cyan; 2:green]
      f F0 rectangle  --background 
    p Text
      t --textColor[0:yellow; 1:white; 2:black]
      t --style[0:normal; 1:bold; 2:italic]
      t --text[0:"goto"; 1:"in"; 2:"space"]
      f F0 text --textColor --style --text
  }



## Les modules 

m p ModuleButton
  doc `
    ##role 
      3-state button               
        
    ##instanciation
      p <PieceName> m ModuleButton
        func --click = <function>
        tag --sendTag = <tag>
        f --mouseOut = <face>
        f --mouseOver = <face>
        f --mousePushed = <face>     
  `
  contract {
    timeline_isolated = true // security
  } 
  params {
    func --click
    tag --sendTag
    f --mouseOut
    f --mouseOver
    f --mousePushed
  }
  modele {
    pf <PieceName> : group  // isolation synchro
        p Button
            t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED; 3:MOUSE_CLICK]
            t stop[0]
            t face[0:FOut ; 1:FOver ; 2:FPushed]
            t click[3:--click]
            t sendTag[3:--sendTag]
            f FOut    = --mouseOut
            f FOver   = --mouseOver
            f FPushed = --mousePushed
  }
  
_____________________________________________________________________________________
_____________________________________________________________________________________

m p ModuleRollover
  doc `
    ##role
      roll-over
      
    ##instanciation
      p <PieceName> m ModuleRollover
      --mouseOut = <face>
      --mouseOver = <face>
  `    
  contract {
    timeline_isolated = true
  } 
  params {
    f --mouseOut
    f --mouseOver
  }
  modele {
    pf <PieceName> : group
        p Rollover
            t tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
            t stop[0]
            t face[0:FOut ; 1:FOver]
            f FOut    = --mouseOut
            f FOver   = --mouseOver
  }

_____________________________________________________________________________________
_____________________________________________________________________________________

m p ModulePages
  doc `
    ##role
        cadre paginé
  
    ##instanciation
        p <PieceName> m ModulePages
            f --fpage_<frameNum>_ = <face>  // <face> sans 'f' au début

        f --fpage_<frameNum>_ parameter generates a Face named Fpage_<frameNum>_    
        Ex :
          Déclaration
            p Album m ModulePages
              f --fpage_0_ = text "message 0"
              f --fpage_1_ = text "message 1"
              f --fpage_2_ = text "message 2"
              
    ##parameter contract
        Pour accéder à une page
            <Piece>.Fpage_<frameNum>_ 
            exemple : _this.album.pages.Fpage_12_
            exemple : _this.album.pages.Fpage_{--numPage}_
                
        Navigation
            <piece>.pages.sendTag(PAGE_<frameNum>_);
  `
  contract {
    timeline_isolated = true
  } 
  params {
    f --fpage_{@frameNum}_
  }
  modele {
    pf <PieceName> : group
        p Pages 
            a isFaceArray 
            t tag[@frameNum:PAGE_{@frameNum}_]
            t stop[0]
            t face[@frameNum:Fpage_{@frameNum}_]
            f Fpage_{@frameNum}_ = --fpage_{@frameNum}_
    }

_____________________________________________________________________________________
_____________________________________________________________________________________

m p ModuleButtonListLine
    doc `
        ##role 
            liste de bouton affichés en en ligne                
        ##instanciation 
            p <PieceName> m ModuleButtonListLine
                c --align = <t pos>
                func --onclick_{@posIndex}_ = <func(x, y, sender)>
                f --mouseOut_{@posIndex}_ = <face> // <face> sans 'f' au début
                f --mouseOver_{@posIndex}_ = <face> // <face> sans 'f' au début
                f --mousePushed_{@posIndex}_ = <face> // <face> sans 'f' au début
            Exemple :
                pf Buttons m ModuleButtonListLine
                  c align = align[0:{@posIndex * 50} 0]
                  p Bt_0_
                    c --onclick_0_ =()=>alert("button 0");
                    f --mouseOut_0_ = text "out 0"
                    f --mouseOver_0_ = text "over 0"
                    f --mousePushed_0_ = text "pushed 0"
                  p Bt_1_
                    c --onclick_1_ =()=>alert("button 0");
                    f --mouseOut_1_ = text "out 0"
                        // note : sans les états suivant, "out 0" est naturellement répété sur les états suivant de MOUSE_OUT => MOUSE_OVER, MOUSE_PUSHED
                    
        ##behavior
            Au clic sur un bouton (onclick), exécute l'action
    `
    params {
        p --pieceBt_{@posIndex}_
        f --mouseOut_{@posIndex}_
        f --mouseOver_{@posIndex}_
        f --mousePushed_{@posIndex}_
        func --onclick_{@posIndex}_
        pos --align
    }
    modele {
        pf <IndexTab> : group 
            a isPieceArray 
            c align = --align
            p Name_{@posIndex}_ = --pieceBt_{@posIndex}_ 
                t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]
                t stop[0]
                t face[0:FOut_{@posIndex}_ ; 1:FOver_{@posIndex}_ ; 2:FPushed_{@posIndex}_ ] 
                c onclick_{@posIndex}_ = --onclick_{@posIndex}_
                f FOut_{@posIndex}_    = --mouseOut_{@posIndex}_
                f FOver_{@posIndex}_   = --mouseOver_{@posIndex}_
                f FPushed_{@posIndex}_ = --mousePushed_{@posIndex}_      
    }  

§extends Tispi rules
- onclick est un mot réservé Tispi - si présent => remplace t click[] 

- Principe de substitution
  Dans un modele, toute valeur peut être remplacée par un paramètre :
  f <name> = --<param>    // substitution de Face
  p <name> = --<param>    // substitution de Piece
  c <name> = --<param>    // substitution de constante
  t <name> = --<param>    // substitution de piste

  Le mécanisme est identique quel que soit le type.
  `= --param` signifie : remplacer ce nœud par la valeur fournie à l'instanciation.

  Pas d'exception — si une substitution ne fonctionne pas sur un type,
  c'est une règle incomplète ou un concept manquant.    

---

m p moduleIndexedPages
  doc `
    ##role 
      Pages dans un cadre indéxé               
        
    ##instanciation 
      p <PieceName> m ModuleIndexedPages
      f --imageIndex_<posIndex>_ = <face> // <face> sans 'f' au début
      f --imageOver_<posIndex>_ = <face> // <face> sans 'f' au début
      f --imagePushed_<posIndex>_ = <face> // <face> sans 'f' au début
      f --doc_<posIndex>_ = <face> // <face> sans 'f' au début

    ##parameter contract
      navigation :
        <piece>.documents.sendTag(PAGE_<posIndex>_);

    ##behavior
      Au clic sur une vignette (MOUSE_CLICK),
      envoie PAGE_<posIndex>_ au parent → affiche le document correspondant.
  `
  contract {
    timeline_isolated = true // security
  } 
  params {
    f --imageIndex_{@posIndex}_
    f --imageOver_{@posIndex}_
    f --imagePushed_{@posIndex}_
    f --doc_{@posIndex}_
  }
  modele {
    pf <PieceName>: group
        pf <IndexTab> : group 
          a isPieceArray 
            pos=pos[0:{@posIndex * 50} 0]
        
          m p moduleIcon   // Plusieurs Pieces affichées
            doc `
                ##role 
                3-state button               
                    
                ##usage 
                p <PieceName> m ModuleIcon
                  c --sendTag = <tag>
                  f --mouseOut = <face>  // <face> sans 'f' au début
                  f --mouseOver = <face> // <face> sans 'f' au début
                  f --mousePushed = <face>   // <face> sans 'f' au début   
            `
            contract {
                timeline_isolated = true // security
            } 
            params {
                tag --sendTag
                f --mouseOut
                f --mouseOver
                f --mousePushed
            }
            modele {
                pf <PieceName> : group  // isolation synchro
                    p Button
                        t tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED; 3:MOUSE_CLICK]
                        t stop[0]
                        t face[0:FOut ; 1:FOver ; 2:FPushed; 3:FOver ] // 3: maintien hover pendant click
                        t sendTag[3:--sendTag]
                        f FOut    = --mouseOut
                        f FOver   = --mouseOver
                        f FPushed = --mousePushed
            }
          p Index_{@posIndex}_ m ModuleIcon
            c --sendTag = _parent._parent.documents PAGE_{@posIndex}_
            f --mouseOut  = --imageIndex_{@posIndex}_
            f --mouseOver  = --imageOver_{@posIndex}_
            f --mousePushed = --imagePushed_{@posIndex}_

        p Documents m ModulePages
          f --fpage_{@posIndex}_ = --doc_{@posIndex}_
  }  
  
_____________________________________________________________________________________
_____________________________________________________________________________________

Rappel : 
- une face unique n'a pas besoin de "piste face"
- un valeur reste présente jusqu'à la key suivante. Même si elle peut se combiner avec la valeur de la keys suivante.
  => donc une face restera active jusqu'à la key suivant ou jusqu'à la fin
  => donc une face unique est toujours active.


  
Nouveauté :
- les pistes de variables
  leur nom est précédé de "--" pour indiquer qu'il sagit de variable. Ex : --text[...] 
  elle indique l'évolution de la valeur d'une variable dans une piste de la barre de temps
  Dans l'exemple ci-dessous, le texte change à chaque temps dans : t --text[...]  
- transition au niveau de la Piece, et au niveau de la key
```
    pf MessIdentification : group
        p Pages
            tr : [0.5s, easeOut, fade]
            t tag[0:MESSAGE_IDLE ; 1:MESSAGE_OK ; 2:MESSAGE_ERROR_0; 3:MESSAGE_ERROR_1]
            t stop[0]
            t sendTag[1:_parent[PAGE_2].foo[STATE_3]]
            t --textContent[0:"en attente"; 1:"Correct, continuons"; 2:"Erreur entrez le pseudo"; 3:"Erreur entrez le code-secret"]
            t --color[0:black, 1:green, 2:red, [0.5s, easeOut, explode]] // Notez que red se propage jusqu-à la frame numéro 3

            f F0 text [100, 200, 400, 30] white ["Arial", 12, B, --color ] --textContent
```

_____________________________________________________________________________________
_____________________________________________________________________________________


m p ModuleRequestPHP
  doc`
    ##role
      Requête PHP générique avec états et isolation temporelle
      
    ##instanciation 
      p <PieceName> m ModuleRequestPHP
        --url = "my_php.php"
        --params = --phpParams
        --sender = _parent.form
        --on-success = "functionOk"
        --on-error = "functionError"

    ##navigation
      <pieceRequest>.requestPhp(params);
        
    ##behavior
      requestPhp() déplace automatiquement le playhead :
          => REQUEST_PENDING (requête en cours)
          => REQUEST_OK      (succès)
          => REQUEST_ERROR   (erreur)
    
    ##requires
      Tispi.phpRequest(--url, --params)
  `
  
  contract {
    timeline_isolated = true
    returns {
      emits on success: sender.receivePhp(--on-success, --message) // cf. --message received with produces
      emits on error:   sender.receivePhp(--on-error, --message)
      produces: --message ( fill by echo of PHP)
    }
  }
  params {
    string --url
    array --params
    p --sender
    func --on-success
    func --on-error
  }   
  
  modele {
    p <PieceName> // isolation synchronique
      c --requestPhp = ()=>{_this.request.sendTag(REQUEST_IDLE)}          
      f F0 group 
        p Request
          t tag[0:REQUEST_WAIT; 1:REQUEST_IDLE; 2:REQUEST_PENDING ; 3:REQUEST_OK ; 4:REQUEST_ERROR]
          t stop[0]
          t face[2:FPending ; 3:FOk ; 4:FError]
          t sendTag[
            3:--sender --on-success --message, _this REQUEST_WAIT;
            4:--sender --on-error --message, _this REQUEST_WAIT
          ]
          t action[
            1: Tispi.io.phpRequest(_this, --url, --params) ;
          ]
          
          f FPending text "Requête en cours…"
          f FOk text ""
          f FError text ""
  }

# L'importance structurelle de la piste sendTag.

sendTag est la représentation canonique des transitions d'une machine à états dans Tispi, permettant une évolution entièrement déterministe et statiquement analysable.

---

## Reformulation correcte de `t sendTag`

### Principe

> **Une valeur de `sendTag` est une suite de tags à envoyer.**

Pas de distinction structurelle :

* ❌ pas "émission externe vs action locale"
* ✔ uniquement une **liste d'envois de tags**

---

## 1. Example walkthrough

```tispi
t sendTag[
  3:--sender --on-success --message, _this REQUEST_WAIT;
  4:--sender --on-error --message, _this REQUEST_WAIT;
]
```

---

## 2. Décomposition correcte

Chaque keyframe contient :

```text
frame : sendTag, sendTag, ...
```

---

### 2.1 Un `sendTag`

Forme générale :

```text
<cible> <tag> [paramètres...]
```

---

### 2.2 Application to this case

#### Première instruction

```tispi
--sender --on-success --message
```

→ envoi d'un tag :

* cible : `--sender`
* tag : `--on-success`
* paramètre : `--message`

---

#### Deuxième instruction

```tispi
_this REQUEST_WAIT
```

→ envoi d'un tag :

* cible : `_this`
* tag : `REQUEST_WAIT`
* pas de paramètre

---

## 3. Syntaxe simplifiée

```ebnf
sendTag ::= send (',' send)* ;

send ::= target tag (value)*
```

---

## 4. Nature du mécanisme

`sendTag` est donc :

> **une piste déclarative d'envoi de tags à des cibles**

Chaque entrée :

* ne décrit pas une action
* ne décrit pas une logique
* décrit uniquement **des envois**

---

## 5. Propriété importante

Contrairement à `action` :

* `action` → exécute du code
* `sendTag` → **déclare des transitions / notifications**

---

## 6. Conséquence conceptuelle

This formulation enforces a purer reading of the model:

> Le système ne fait pas "des actions"
> Il **propage des états (tags)**

---

## 7. Résumé final

✔ Une keyframe de `sendTag` = liste de tags à envoyer
✔ Chaque élément = `cible + tag + paramètres éventuels`
✔ Pas de notion de "bloc"
✔ Pas de hiérarchie interne

---

## Formulation propre

> **`t sendTag` est une piste qui décrit, pour chaque frame, une liste de tags à envoyer à des cibles données, éventuellement accompagnés de paramètres.**

## Classic Tispi pitfalls

- Forgetting that modules are Pieces

- Wrong parameter type in a module
The Tispi engine checks whether a parameter has the wrong type in a module.

# extends Tispi rules
- Têtes de path réservées :
    _this    : désigne la Piece courante
    _parent  : désigne la Piece parent
    _brother : désigne l'espace des Pieces sœurs du groupe courant
    
    Syntaxe :
    <path> ::= _this
            | _parent
            | _brother.<PieceName>
            | <path>.<PieceName>
            | <path>.<propertyName>
    
    Règles :
    - Un path contextuel doit commencer par une tête de path réservée.
    - `_brother` doit toujours être suivi du nom d'une Piece sœur.
    - Les têtes de path réservées ne peuvent pas être utilisées comme noms de Piece.
    - Rappel : a referenced sibling Piece must exist and be uniquely identified within its parent Face group.
    
- @frameNum : désigne l'index courant de la Piece 
    Meta variable available only in module definitions
    - @<path>.index
      Référence à l'index d'une autre Piece.
      Utilisable dans tout modele imbriqué dans un module indexé.
      Exemple : 
        {@_parent.index} = référence à l'index de la Pièce parent
        {@pieceName.index} = référence à une pièce nommée pieceName

- Convention de nommage :
    | Élément | Forme | Exemple |
    |---|---|---|
    | Variable auteur | `--camelCase` | `--numPage`, `--mouseOut` |
    | Placeholder | `@camelCase` | `@frameNum`, `@parentIndex` |
    | Nœud indexé | `Name_{@frameNum}_` | `Fpage_{@frameNum}_` → `Fpage_12_` |
    | Tag système | SCREAMING_SNAKE        | MOUSE_OUT, MOUSE_OVER   |
    | Tag indexé  | NAME_{@frameNum}_      | PAGE_{@frameNum}_ → PAGE_12_ |

- {} : requis pour toute variable insérée dans un nom de nœud,
  un littéral, ou une expression calculée.
  
  | Contexte | Notation | Exemple |
  |---|---|---|
  | Expression calculée | `{}` | `{@frameNum * 50}` |
  | Variable dans un nom | `{}` | `Fpage_{@frameNum}_` |
  | Variable auteur dans un nom | `{}` | `Fpage_{--numPage}_` |
  | Référence simple hors nom | sans `{}` | `--var`, `@frameNum` |  

- a isFaceArray : attribut de Piece — indique que la Piece 
  contient une collection de Faces indexées expansibles.
  Le moteur génère une instance de Face par @index trouvé 
  dans les params de type f --Name_{@index}_. 

- a isPieceArray : attribut de Face — indique que la Face
  contient une collection de Pieces expansibles.
  Non structurel — optimisation de description uniquement.
  Propriétés disponibles :
    pos = pos[0:{@index * 50} 0]  // position calculée par index 

- tag : type "tag" pour une variable
  tag ::= pathPiece string
  pathPiece ::= (pathHeader "." (pieceName)*)? '.' string
  pathHeader ::= "_this" | "_parent" | "_brother"
  pieceName ::= string

- @posIndex : meta-variable système disponible dans les définitions 
  de modules. Désigne le numéro de frame courant dans le contexte 
  d'expansion indexée.

- Un module déclaré dans un modele est local à ce modele.
  Il n'est pas accessible depuis l'extérieur du module parent.
  Sa portée est limitée à la branche dans laquelle il est déclaré. 
