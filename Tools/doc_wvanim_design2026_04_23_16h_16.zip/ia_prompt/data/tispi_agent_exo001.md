# Exercise 1

Here, you are a Tispi script validator.
Expected answer: yes or no, with one explanatory line.

P root
F f0 group

```
PF bg : image "myimage.png"  

P button1  
  T tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]  
  T stop[0]  
  T face[0:fOut ; 1:fOver ; 2:fPushed]  
  F fOut    image "btn1_out.png"  
  F fOver   image "btn1_over.png"  
  F fPushed image "btn1_pushed.png"  

P button2  
  T tag[0:MOUSE_OUT ; 1:MOUSE_OVER ; 2:MOUSE_PUSHED]  
  T stop[0]  
  T face[0:fOut ; 1:fOver ; 2:fPushed]  
  F fOut    image "btn2_out.png"  
  F fOver   image "btn2_over.png"  
  F fPushed image "btn2_pushed.png"
```
