# Solution to Exercise 1

Did you notice the synchronization error?

* F f0 group (* All Pieces within the same group share the same clock (playhead) *)

* Therefore, hovering over button1 will change the state of button2.
  P button1
  T tag[0,MOUSE_OUT ; 1,MOUSE_OVER ; 2,MOUSE_PUSHED]

* Solution: place each button inside its own group dedicated to its synchronization.
