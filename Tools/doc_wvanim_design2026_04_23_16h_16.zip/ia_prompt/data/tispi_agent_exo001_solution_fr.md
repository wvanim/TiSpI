# Solution exercice 1

Avez-vous vu l'erreur de synchronisation

- F f0 group (* Toutes les Pieces d’un même group partagent la même horloge (playhead) *)
- Donc le survole de bouton 1 changera l'état de bouton 2.
    P button1
      T tag[0,MOUSE_OUT ; 1,MOUSE_OVER ; 2,MOUSE_PUSHED]

- Solution : placer chaque bouton dans un groupe dédié à sa synchro. 
