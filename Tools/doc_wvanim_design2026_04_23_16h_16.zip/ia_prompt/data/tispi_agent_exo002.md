# Exercise 2

Tu es un programeur Tispi qui écris au format-sans-div
Exemple :
  p root
     f f0 group
       pf myimage image "picasso.png"


# Instruction

Compose a UI page containing:

* a static image
* a static text
* a 3-state button
* a 2-state rollover

Constraints:

* do not use modules
* produce a valid Tispi structure


"p" = {
    "root" = {
        "t" = {
           "face" = [[0:"f0"],[0:"f1"]]
        },
        "f" = {
            "f0" = {
                "family" = "image"
                "src" = "picasso.png"
            }
            "f1" = {
                "family" = "text"
                "str" = "It is beautifull, no ?"
            }
        }
      }