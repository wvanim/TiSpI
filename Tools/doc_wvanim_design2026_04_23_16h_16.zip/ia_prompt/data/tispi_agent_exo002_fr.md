# exercice 2

Compose une page UI contenant :
- une image statique
- un texte statique
- un bouton à 3 états
- un rollover à 2 états

Contraintes :
- ne pas utiliser de modules
- produire une structure Tispi valide

