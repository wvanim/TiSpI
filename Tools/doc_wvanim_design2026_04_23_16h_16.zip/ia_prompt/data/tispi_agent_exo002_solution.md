# Solution to Exercise 2

Compare your answer to this structure.

P root  (* optimization is also accepted: PF root: group *)
T tag[0,PAGE] (* optional *)
T stop[0]     (* optional *)
T face[0,f0]  (* optional *)
F f0 group    (* the name is optional *)

```
P bg    (* optimization also accepted => PF bg : image "myimage.png" *)  
    F image "myimage.png" (* the Face name is optional since it is the only one in the Piece *)  

P label    (* optimization also accepted => PF label : text "Hello world" *)  
    F text "Hello world" (* the Face name is optional since it is the only one in the Piece *)  

P isolation_button (* synchronization required, timeline conflict *)  
                   (* + optimization also accepted: PF isolation_button : group *)  
  F f0 group  (* name optional, since it is the only Face in the Piece *)  
    P button  
      T tag[0,MOUSE_OUT ; 1,MOUSE_OVER ; 2,MOUSE_PUSHED] (* verify the tags *)  
      T stop[0] (* only on 0 *)  
      T face[0,fOut ; 1,fOver ; 2,fPushed] (* verify the Faces — names matter for matching *)  
      F fOut    image "btn_out.png"   (* must match the first name in the face track *)  
      F fOver   image "btn_over.png"  (* must match the second name *)  
      F fPushed image "btn_pushed.png" (* must match the third name *)  

P isolation_rollover   (* same as the button, but with only 2 states *)  
  F f0 group  
    P rollover  
      T tag[0,MOUSE_OUT ; 1,MOUSE_OVER]  
      T stop[0]  
      T face[0,fOut ; 1,fOver]  
      F fOut  image "roll_out.png"  
      F fOver image "roll_over.png"  
```

## Errors if you do not respect:

* the names of your Pieces that are direct children of a Face must be different
  Example: Pieces `bg`, `label`, `isolation_button`, and `isolation_rollover` must all be different, because they are direct children of the same group

* and reciprocally: the names of your Faces that are direct children of a Piece must be different

## Not considered errors

* anything marked as **optional**
* your names differ from this example
* if you used group-Faces instead of image-Faces (this is even considered a better answer)
* identical Piece names in different groups: a Piece name only needs to be unique among its siblings (other Pieces within the same group-Face)
* identical Face names in different Pieces: a Face name only needs to be unique among the Faces within the same Piece

If you have errors, list them without explanation.
List only the errors.
