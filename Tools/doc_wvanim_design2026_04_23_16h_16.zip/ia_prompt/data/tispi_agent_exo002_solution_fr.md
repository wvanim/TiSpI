# solution exercice n°2

Comparez votre réponse à cet structure.

P root  (* l'optimisation est aussi accepté : PF root: group *)  
  T tag[0,PAGE] (*optionnel*)
  T stop[0]     (*optionnel*)
  T face[0,f0] (*optionnel*)
  F f0 group (* le nom est optionnel *) 

    P bg    (* optimisation aussi accepté => PF bg : image "myimage.png" *) 
        F image "myimage.png" (* le nom de la Face est optionnelle car elle est seul dans la Piece *) 

    P label    (* optimisation aussi accepté => PF label : text "Hello world"*) 
        F text "Hello world" (* le nom de la Face est optionnelle car elle est seule dans la Piece*)  

    P isolation_button (* obligatoire synchro,  conflit de timeline *) 
                                 (*  +  et optimisation aussi acceptée : PF isolation_button : group *) 
      F f0 group  (* Nom optionnel, puisque seule Face dans la Piece *) 
        P button 
          T tag[0,MOUSE_OUT ; 1,MOUSE_OVER ; 2,MOUSE_PUSHED] (* Vérifier les balises *) 
          T stop[0] (* Uniquement sur 0 *) 
          T face[0,fOut ; 1,fOver ; 2,fPushed] (* vérifier les Faces - les noms importent peut.*) 
          F fOut    image "btn_out.png"   (* Le nom doit correspondre au 1er nom de la piste F face *) 
          F fOver   image "btn_over.png" (*  correspondance avec le 2ème nom *) 
          F fPushed image "btn_pushed.png" (*  correspondance avec le 2ème nom  *) 

    P isolation_rollover   (* Identique au bouton, avec seulement 2 états. *) 
      F f0 group
        P rollover
          T tag[0,MOUSE_OUT ; 1,MOUSE_OVER]
          T stop[0]
          T face[0,fOut ; 1,fOver]
          F fOut  image "roll_out.png"
          F fOver image "roll_over.png"

## Erreurs si vous ne respectez pas :          
- vos noms de Pièce filles directs d'une Face sont différents 
Exemple : Pieces : bg, label, isolation_button et isolation_rollover doivent être différent. Car ces pièces sont des fils directs d'un même groupe
- et réciproquement : vos noms de Face filles directs d'une Piece sont différents 

## Ne sont pas des erreurs
- tout ce qui est annoté **optionnel**
- vos noms sont différents de cette Exemple.
- si vous avez placé des Face-groupes à la place des Face-images. C'est même considéré comme meilleure réponse
- des noms de pièces identiques dans des groupes différents : le nom d'une Pièce n'a besoin d'être unique que par rapport à ses "frères" (les autres Pièces au sein d'une même Face-groupe).
- des noms de faces identiques dans des pieces différents : le nom d'une Face n'a besoin d'être unique que par rapport aux autres Faces de la même Pièce.

Si vous avez des erreurs, pouvez vous les lister, sans explication.
Ne listez que les erreurs.


 
