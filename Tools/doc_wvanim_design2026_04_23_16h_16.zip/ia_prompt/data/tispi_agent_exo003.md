# Exercise 3

1 - Can you explain what this script does?
2 - Can you verify whether its syntax and logic are correct?
Write only the errors if there are any.

---

P root
F f0 group

```
P header  
  F f0 group  
    P btn_home M moduleButton  
      --mouse-out    = F text "Home"  
      --mouse-over   = F text "Home •"  
      --mouse-pushed = F text "Home •"  
      --click        = (e) => { pages_root.sendTag(PAGE_0); }  
    P btn_gallery M moduleButton  
      --mouse-out    = F text "Gallery"  
      --mouse-over   = F text "Gallery •"  
      --mouse-pushed = F text "Gallery •"  
      --click        = (e) => { pages_root.sendTag(PAGE_1); }  
    P btn_contact M moduleButton  
      --mouse-out    = F text "Contact"  
      --mouse-over   = F text "Contact •"  
      --mouse-pushed = F text "Contact •"  
      --click        = (e) => { pages_root.sendTag(PAGE_2); }  

P pages_root M modulePages  

  --page-0 = F group  
    PF content : text "Home Page"  

  --page-1 = F group  
    P products_pages M modulePages  

      --page-0 = F group  
        P vue_pages M modulePages  

          --page-0 = F group  
            P isolationZoom  
              F f0 group  
                P zoom  
                  T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]  
                  T stop[0]  
                  T face[0:fOut ; 1:fOver]  
                  T pos[0: 0 0 ; 1: -50 -50]  
                  T size[0: 400 300 ; 1: 500 375]  
                  F fOut  image "product1_view1.png"  
                  F fOver image "product1_view1.png"  
            PF desc : text "Product 1 — View 1"  

          --page-1 = F group  
            P isolationZoom  
              F f0 group  
                P zoom  
                  T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]  
                  T stop[0]  
                  T face[0:fOut ; 1:fOver]  
                  T pos[0: 0 0 ; 1: -50 -50]  
                  T size[0: 400 300 ; 1: 500 375]  
                  F fOut  image "product1_view2.png"  
                  F fOver image "product1_view2.png"  
            PF desc : text "Product 1 — View 2"  

          --page-2 = F group  
            P isolationZoom  
              F f0 group  
                P zoom  
                  T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]  
                  T stop[0]  
                  T face[0:fOut ; 1:fOver]  
                  T pos[0: 0 0 ; 1: -50 -50]  
                  T size[0: 400 300 ; 1: 500 375]  
                  F fOut  image "product1_view3.png"  
                  F fOver image "product1_view3.png"  
            PF desc : text "Product 1 — View 3"  

        P thumbnails  
          F f0 group  
            P thumb1 M moduleButton  
              --mouse-out    = F image "product1_thumb1.png"  
              --mouse-over   = F image "product1_thumb1_over.png"  
              --mouse-pushed = F image "product1_thumb1_over.png"  
              --click        = (e) => { vue_pages.sendTag(PAGE_0); }  
            P thumb2 M moduleButton  
              --mouse-out    = F image "product1_thumb2.png"  
              --mouse-over   = F image "product1_thumb2_over.png"  
              --mouse-pushed = F image "product1_thumb2_over.png"  
              --click        = (e) => { vue_pages.sendTag(PAGE_1); }  
            P thumb3 M moduleButton  
              --mouse-out    = F image "product1_thumb3.png"  
              --mouse-over   = F image "product1_thumb3_over.png"  
              --mouse-pushed = F image "product1_thumb3_over.png"  
              --click        = (e) => { vue_pages.sendTag(PAGE_2); }  

        P add_cart M moduleButton  
          --mouse-out    = F image "btn_cart_out.png"  
          --mouse-over   = F image "btn_cart_over.png"  
          --mouse-pushed = F image "btn_cart_pushed.png"  
          --click        = (e) => { addToCart("product1"); }  

      --page-1 = F group  
        P vue_pages M modulePages  

          --page-0 = F group  
            P isolationZoom  
              F f0 group  
                P zoom  
                  T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]  
                  T stop[0]  
                  T face[0:fOut ; 1:fOver]  
                  T pos[0: 0 0 ; 1: -50 -50]  
                  T size[0: 400 300 ; 1: 500 375]  
                  F fOut  image "product2_view1.png"  
                  F fOver image "product2_view1.png"  
            PF desc : text "Product 2 — View 1"  

          --page-1 = F group  
            P isolationZoom  
              F f0 group  
                P zoom  
                  T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]  
                  T stop[0]  
                  T face[0:fOut ; 1:fOver]  
                  T pos[0: 0 0 ; 1: -50 -50]  
                  T size[0: 400 300 ; 1: 500 375]  
                  F fOut  image "product2_view2.png"  
                  F fOver image "product2_view2.png"  
            PF desc : text "Product 2 — View 2"  

          --page-2 = F group  
            P isolationZoom  
              F f0 group  
                P zoom  
                  T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]  
                  T stop[0]  
                  T face[0:fOut ; 1:fOver]  
                  T pos[0: 0 0 ; 1: -50 -50]  
                  T size[0: 400 300 ; 1: 500 375]  
                  F fOut  image "product2_view3.png"  
                  F fOver image "product2_view3.png"  
            PF desc : text "Product 2 — View 3"  

        P thumbnails  
          F f0 group  
            P thumb1 M moduleButton  
              --mouse-out    = F image "product2_thumb1.png"  
              --mouse-over   = F image "product2_thumb1_over.png"  
              --mouse-pushed = F image "product2_thumb1_over.png"  
              --click        = (e) => { vue_pages.sendTag(PAGE_0); }  
            P thumb2 M moduleButton  
              --mouse-out    = F image "product2_thumb2.png"  
              --mouse-over   = F image "product2_thumb2_over.png"  
              --mouse-pushed = F image "product2_thumb2_over.png"  
              --click        = (e) => { vue_pages.sendTag(PAGE_1); }  
            P thumb3 M moduleButton  
              --mouse-out    = F image "product2_thumb3.png"  
              --mouse-over   = F image "product2_thumb3_over.png"  
              --mouse-pushed = F image "product2_thumb3_over.png"  
              --click        = (e) => { vue_pages.sendTag(PAGE_2); }  

        P add_cart M moduleButton  
          --mouse-out    = F image "btn_cart_out.png"  
          --mouse-over   = F image "btn_cart_over.png"  
          --mouse-pushed = F image "btn_cart_pushed.png"  
          --click        = (e) => { addToCart("product2"); }  

      --page-2 = F group  
        P vue_pages M modulePages  
          --page-0 = F group  
            P isolationZoom  
              F f0 group  
                P zoom  
                  T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]  
                  T stop[0]  
                  T face[0:fOut ; 1:fOver]  
                  T pos[0: 0 0 ; 1: -50 -50]  
                  T size[0: 400 300 ; 1: 500 375]  
                  F fOut  image "product3_placeholder.png"  
                  F fOver image "product3_placeholder.png"  
            PF desc : text "Product 3 — coming soon"  

        P thumbnails  
          F f0 group  
            P thumb1 M moduleButton  
              --mouse-out    = F image "product3_thumb1.png"  
              --mouse-over   = F image "product3_thumb1_over.png"  
              --mouse-pushed = F image "product3_thumb1_over.png"  
              --click        = (e) => { vue_pages.sendTag(PAGE_0); }  

        P add_cart M moduleButton  
          --mouse-out    = F image "btn_cart_out.png"  
          --mouse-over   = F image "btn_cart_over.png"  
          --mouse-pushed = F image "btn_cart_pushed.png"  
          --click        = (e) => { addToCart("product3"); }  

  --page-2 = F group  
    PF contact : text "Contact Page"  

P footer  
  F f0 group  
    PF footerText : text "© 2025 My Shop"  
    P footer_rollover M moduleRollover  
      --mouse-out  = F text "Contact us"  
      --mouse-over = F text "Contact us →"
```
