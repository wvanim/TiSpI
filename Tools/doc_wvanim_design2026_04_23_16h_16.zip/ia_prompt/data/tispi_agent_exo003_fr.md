# exercice 3

1 - Pouvez-vous expliquer ce que fait ce script
2 - pouvez-vous vérifier si il sa syntaxe et sa logique sont correctes.
N'inscrivez que les erreurs si il y en a

---

P root
  F f0 group

    P header
      F f0 group
        P btn_home M moduleButton
          --mouse-out    = F text "Accueil"
          --mouse-over   = F text "Accueil •"
          --mouse-pushed = F text "Accueil •"
          --click        = (e) => { pages_root.sendTag(PAGE_0); }
        P btn_gallery M moduleButton
          --mouse-out    = F text "Galerie"
          --mouse-over   = F text "Galerie •"
          --mouse-pushed = F text "Galerie •"
          --click        = (e) => { pages_root.sendTag(PAGE_1); }
        P btn_contact M moduleButton
          --mouse-out    = F text "Contact"
          --mouse-over   = F text "Contact •"
          --mouse-pushed = F text "Contact •"
          --click        = (e) => { pages_root.sendTag(PAGE_2); }

    P pages_root M modulePages

      --page-0 = F group
        PF content : text "Page Accueil"

      --page-1 = F group
        P products_pages M modulePages

          --page-0 = F group
            P vue_pages M modulePages

              --page-0 = F group
                P isolationZoom
                  F f0 group
                    P zoom
                      T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
                      T stop[0]
                      T face[0:fOut ; 1:fOver]
                      T pos[0: 0 0 ; 1: -50 -50]
                      T size[0: 400 300 ; 1: 500 375]
                      F fOut  image "product1_vue1.png"
                      F fOver image "product1_vue1.png"
                PF desc : text "Produit 1 — Vue 1"

              --page-1 = F group
                P isolationZoom
                  F f0 group
                    P zoom
                      T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
                      T stop[0]
                      T face[0:fOut ; 1:fOver]
                      T pos[0: 0 0 ; 1: -50 -50]
                      T size[0: 400 300 ; 1: 500 375]
                      F fOut  image "product1_vue2.png"
                      F fOver image "product1_vue2.png"
                PF desc : text "Produit 1 — Vue 2"

              --page-2 = F group
                P isolationZoom
                  F f0 group
                    P zoom
                      T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
                      T stop[0]
                      T face[0:fOut ; 1:fOver]
                      T pos[0: 0 0 ; 1: -50 -50]
                      T size[0: 400 300 ; 1: 500 375]
                      F fOut  image "product1_vue3.png"
                      F fOver image "product1_vue3.png"
                PF desc : text "Produit 1 — Vue 3"

            P vignettes
              F f0 group
                P thumb1 M moduleButton
                  --mouse-out    = F image "product1_thumb1.png"
                  --mouse-over   = F image "product1_thumb1_over.png"
                  --mouse-pushed = F image "product1_thumb1_over.png"
                  --click        = (e) => { vue_pages.sendTag(PAGE_0); }
                P thumb2 M moduleButton
                  --mouse-out    = F image "product1_thumb2.png"
                  --mouse-over   = F image "product1_thumb2_over.png"
                  --mouse-pushed = F image "product1_thumb2_over.png"
                  --click        = (e) => { vue_pages.sendTag(PAGE_1); }
                P thumb3 M moduleButton
                  --mouse-out    = F image "product1_thumb3.png"
                  --mouse-over   = F image "product1_thumb3_over.png"
                  --mouse-pushed = F image "product1_thumb3_over.png"
                  --click        = (e) => { vue_pages.sendTag(PAGE_2); }

            P add_cart M moduleButton
              --mouse-out    = F image "btn_panier_out.png"
              --mouse-over   = F image "btn_panier_over.png"
              --mouse-pushed = F image "btn_panier_pushed.png"
              --click        = (e) => { addToCart("product1"); }

          --page-1 = F group
            P vue_pages M modulePages

              --page-0 = F group
                P isolationZoom
                  F f0 group
                    P zoom
                      T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
                      T stop[0]
                      T face[0:fOut ; 1:fOver]
                      T pos[0: 0 0 ; 1: -50 -50]
                      T size[0: 400 300 ; 1: 500 375]
                      F fOut  image "product2_vue1.png"
                      F fOver image "product2_vue1.png"
                PF desc : text "Produit 2 — Vue 1"

              --page-1 = F group
                P isolationZoom
                  F f0 group
                    P zoom
                      T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
                      T stop[0]
                      T face[0:fOut ; 1:fOver]
                      T pos[0: 0 0 ; 1: -50 -50]
                      T size[0: 400 300 ; 1: 500 375]
                      F fOut  image "product2_vue2.png"
                      F fOver image "product2_vue2.png"
                PF desc : text "Produit 2 — Vue 2"

              --page-2 = F group
                P isolationZoom
                  F f0 group
                    P zoom
                      T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
                      T stop[0]
                      T face[0:fOut ; 1:fOver]
                      T pos[0: 0 0 ; 1: -50 -50]
                      T size[0: 400 300 ; 1: 500 375]
                      F fOut  image "product2_vue3.png"
                      F fOver image "product2_vue3.png"
                PF desc : text "Produit 2 — Vue 3"

            P vignettes
              F f0 group
                P thumb1 M moduleButton
                  --mouse-out    = F image "product2_thumb1.png"
                  --mouse-over   = F image "product2_thumb1_over.png"
                  --mouse-pushed = F image "product2_thumb1_over.png"
                  --click        = (e) => { vue_pages.sendTag(PAGE_0); }
                P thumb2 M moduleButton
                  --mouse-out    = F image "product2_thumb2.png"
                  --mouse-over   = F image "product2_thumb2_over.png"
                  --mouse-pushed = F image "product2_thumb2_over.png"
                  --click        = (e) => { vue_pages.sendTag(PAGE_1); }
                P thumb3 M moduleButton
                  --mouse-out    = F image "product2_thumb3.png"
                  --mouse-over   = F image "product2_thumb3_over.png"
                  --mouse-pushed = F image "product2_thumb3_over.png"
                  --click        = (e) => { vue_pages.sendTag(PAGE_2); }

            P add_cart M moduleButton
              --mouse-out    = F image "btn_panier_out.png"
              --mouse-over   = F image "btn_panier_over.png"
              --mouse-pushed = F image "btn_panier_pushed.png"
              --click        = (e) => { addToCart("product2"); }

          --page-2 = F group
            P vue_pages M modulePages
              --page-0 = F group
                P isolationZoom
                  F f0 group
                    P zoom
                      T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
                      T stop[0]
                      T face[0:fOut ; 1:fOver]
                      T pos[0: 0 0 ; 1: -50 -50]
                      T size[0: 400 300 ; 1: 500 375]
                      F fOut  image "product3_placeholder.png"
                      F fOver image "product3_placeholder.png"
                PF desc : text "Produit 3 — à venir"

            P vignettes
              F f0 group
                P thumb1 M moduleButton
                  --mouse-out    = F image "product3_thumb1.png"
                  --mouse-over   = F image "product3_thumb1_over.png"
                  --mouse-pushed = F image "product3_thumb1_over.png"
                  --click        = (e) => { vue_pages.sendTag(PAGE_0); }

            P add_cart M moduleButton
              --mouse-out    = F image "btn_panier_out.png"
              --mouse-over   = F image "btn_panier_over.png"
              --mouse-pushed = F image "btn_panier_pushed.png"
              --click        = (e) => { addToCart("product3"); }

      --page-2 = F group
        PF contact : text "Page Contact"

    P footer
      F f0 group
        PF footerText : text "© 2025 Ma Boutique"
        P footer_rollover M moduleRollover
          --mouse-out  = F text "Nous contacter"
          --mouse-over = F text "Nous contacter →"
