This script is error-free.

* that the thumbnails were button modules, which guarantees synchronization isolation by contract.

## False errors — did you avoid them?

1. **Violation of P/F alternation** (fundamental rule #1), multiple times:

   * Several `P isolationZoom` directly contain `F f0 group` followed by `P zoom` → correct.
   * `P zoom` contains both `T` (tracks) and `F` → **correct**.
   * **Actual issue**: In product subpages, `P isolationZoom` is placed directly inside a `group` Face without proper encapsulation in some places.

> Answer: There is no reason to encapsulate if it is unnecessary. Otherwise, tree depth increases unnecessarily.

---

2. **Lack of temporal isolation** (major logical issue):

   * The `P zoom` contain tracks: `T tag`, `T stop`, `T face`, `T pos`, `T size`.
   * They are placed **deeply** inside nested `modulePages`, but without systematic isolation via a dedicated `group` Face for each zoom. The timeline may become polluted between different page levels.

> Answer: Time/Space alternation and clock isolation within each group protect against timeline “pollution” between different groups.

---

3. **Non-unique Face and Piece names among siblings**:

   * In each `P thumbnails`, you have multiple `P thumb1`, `P thumb2`, `P thumb3` → **identical names among siblings** → forbidden.
   * Same issue with `P add_cart` repeated in each product.

> In different subgroups, Pieces with identical names are not siblings.

---

4. **Incorrect use of module parameters**:

   * In `btn_home`, `btn_gallery`, etc.: `--mouse-out = F text "Home"` → incorrect syntax. A Face cannot be directly placed as a parameter value; it must be declared first or referenced.

> There is no restriction preventing a Face from being directly assigned to a variable.

---

5. **Excessive repetition and poor factorization**:

   * The `isolationZoom + zoom` block is copy-pasted 7 times with very little variation → very poor maintainability (though more a design issue than a syntax error).

> Correct, but this is not a syntax error nor blocking for logic.
> The solution: create a module. Did you identify this solution?
