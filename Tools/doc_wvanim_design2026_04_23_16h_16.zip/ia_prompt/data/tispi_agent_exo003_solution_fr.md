


This script is error-free?

- that the thumbnails were button modules, which guarantees synchronous isolation by contract.

## Fausses erreurs, les avez-vous évité ? 

1. **Violation de l’alternance P/F** (règle fondamentale n°1) plusieurs fois :
   - Plusieurs `P isolationZoom` contiennent directement `F f0 group` puis `P zoom` → correct.
   - Mais `P zoom` contient des `T` (pistes) **et** des `F` → **correct**.
   - **Problème réel** : Dans les sous-pages des produits, `P isolationZoom` est placé directement dans une Face `group` sans être encapsulé correctement dans certains endroits.
   
> Réponse : Aucune raison d'encapsuler si c'est inutile. Sinon on aumente inutilement la profondeur.   

---

2. **Manque d’isolation temporelle** (problème majeur de logique) :
   - Les `P zoom` contiennent des pistes `T tag`, `T stop`, `T face`, `T pos`, `T size`.
   - Ils sont placés **profondément** dans des imbrications de `modulePages`, mais sans isolation systématique via une Face `group` dédiée pour chaque zoom. Le timeline risque de se polluer entre les différents niveaux de pages.

> Réponse : l'alterance Temps/espace et l'isolation de horloges dans chaque groupe protège de la "pollution" des timelines entre les différents groupes 

---

3. **Noms de Faces et de Pieces non uniques entre siblings** :
   - Dans chaque `P vignettes`, vous avez plusieurs `P thumb1`, `P thumb2`, `P thumb3` → **noms identiques entre siblings** → interdit.
   - Même problème avec `P add_cart` répété dans chaque produit.

> Dans des sous-groupes différents, les Pieces avec des noms identiques ne sont pas siblings

---

4. **Utilisation incorrecte des paramètres des modules** :
   - Dans `btn_home`, `btn_gallery`, etc. : `--mouse-out = F text "Accueil"` → syntaxe incorrecte. On ne peut pas mettre directement `F text ...` dans la valeur d’un paramètre. Il faut déclarer la Face avant ou utiliser une référence.

> Aucune conséquence interdit de mettre directement Un Face dans un variable.

---

5. **Répétition excessive et mauvaise factorisation** :
   - Le bloc `isolationZoom + zoom` est copié-collé 7 fois avec très peu de variation → très mauvais pour la maintenance (mais c’est plus un problème de design qu’une erreur de syntaxe pure).

> Ok, mais ce n'est pas une erreur de syntaxe ni bloquant pour la logique.
La solution : créer un module. Aviez-vous cette solution ?
