# exercice 3

1 - Pouvez-vous expliquer ce que fait ce script
2 - pouvez-vous vérifier si il est correct.
N'inscrivez que les erreurs si il y en a

---




P root
  F f0 group

    P pages_root M modulePages
      --page-0 = F group
        P header
          F f0 group
            P btn_home M moduleButton
              --mouse-out    = F text "Accueil"
              --mouse-over   = F text "Accueil •"
              --mouse-pushed = F text "Accueil •"
              --click        = (e) => { parent(pages_root).gotoFrame(PAGE0); }
            P btn_gallery M moduleButton
              --mouse-out    = F text "Galerie"
              --mouse-over   = F text "Galerie •" 
              --mouse-pushed = F text "Galerie •"
              --click        = (e) => { parent(pages_root).gotoFrame(PAGE1); }
            P btn_contact M moduleButton
              --mouse-out    = F text "Contact"
              --mouse-over   = F text "Contact •"
              --mouse-pushed = F text "Contact •"
              --click        = (e) => { parent(pages_root).gotoFrame(PAGE2); }

      --page-1 = F group

        P header
          F f0 group
            P btn_home M moduleButton
              --mouse-out    = F text "Accueil"
              --mouse-over   = F text "Accueil •"
              --mouse-pushed = F text "Accueil •"
              --click        = (e) => { parent(pages_root).gotoFrame(PAGE0); }
            P btn_gallery M moduleButton
              --mouse-out    = F text "Galerie"
              --mouse-over   = F text "Galerie •"
              --mouse-pushed = F text "Galerie •"
              --click        = (e) => { parent(pages_root).gotoFrame(PAGE1); }
            P btn_contact M moduleButton
              --mouse-out    = F text "Contact"
              --mouse-over   = F text "Contact •"
              --mouse-pushed = F text "Contact •"
              --click        = (e) => { parent(pages_root).gotoFrame(PAGE2); }

        P zoneProduct
          F f0 group

            P products_pages M modulePages
              --page-0 = F group

                P isolationZoom
                  F f0 group
                    P zoom
                      T tag[0:MOUSE_OUT ; 1:MOUSE_OVER]
                      T stop[0]
                      T face[0,fOut ; 1,fOver]
                      T pos[0: 0 0 ; 1: -50 -50]
                      T size[0: 400 300 ; 1: 500 375]
                      F fOut  image "product1_main.png"
                      F fOver image "product1_main.png"

                P vignettes
                  F f0 group
                    V --desc_pages = parent(products_pages).desc_pages
                    P thumb1 M moduleButton
                      --mouse-out    = F image "product1_thumb1.png"
                      --mouse-over   = F  image "product1_thumb1_over.png"
                      --mouse-pushed = F image "product1_thumb1_over.png"
                      --click        = (e) => { --desc_pages.gotoFrame(PAGE0); }
                    P thumb2 M moduleButton
                      --mouse-out    = F image "product1_thumb2.png"
                      --mouse-over   = F image "product1_thumb2_over.png"
                      --mouse-pushed = F image "product1_thumb2_over.png"
                      --click        = (e) => { --desc_pages.gotoFrame(PAGE1); }
                    P thumb3 M moduleButton
                      --mouse-out    = F image "product1_thumb3.png"
                      --mouse-over   = F image "product1_thumb3_over.png"
                      --mouse-pushed = F image "product1_thumb3_over.png"
                      --click        = (e) => { --desc_pages.gotoFrame(PAGE2); }

                P desc_pages M modulePages
                  --page-0 = F group
                    PF desc : text "Produit 1 — Vue 1"
                  --page-1 = F group
                    PF desc : text "Produit 1 — Vue 2"
                  --page-2 = F group
                    PF desc : text "Produit 1 — Vue 3"

                P add_cart M moduleButton
                  --mouse-out    = F image "btn_panier_out.png"
                  --mouse-over   = F image "btn_panier_over.png"
                  --mouse-pushed = F image "btn_panier_pushed.png"
                  --click        = (e) => { addToCart("product1"); }

              --page-1 = F group
                PF placeholder : text "Produit 2"

              --page-2 = F group
                PF placeholder : text "Produit 3"

      --page-2 = F group
        P header
          F f0 group
            P btn_home M moduleButton
              --mouse-out    = F text "Accueil"
              --mouse-over   = F text "Accueil •"
              --mouse-pushed = F text "Accueil •"
              --click        = (e) => { gotoFrame(PAGE0); }
            P btn_gallery M moduleButton
              --mouse-out    = F text "Galerie"
              --mouse-over   = F text "Galerie •"
              --mouse-pushed = F text "Galerie •"
              --click        = (e) => { gotoFrame(PAGE1); }
            P btn_contact M moduleButton
              --mouse-out    = F text "Contact"
              --mouse-over   = F text "Contact •"
              --mouse-pushed = F text "Contact •"
              --click        = (e) => { gotoFrame(PAGE2); }

        PF contact : text "Page Contact"

    P footer
      F f0 group
        PF footerText : text "© 2025 Ma Boutique"
        P footer_rollover M moduleRollover
          --mouse-out  = F text "Nous contacter"
          --mouse-over = F text "Nous contacter →"
  